# Read by codabench. Exposes make_agent (default competition reward).
from .my_agent import make_agent
