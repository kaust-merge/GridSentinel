"""(ZE3) (S2CLNSM6CZ3) D-1 on ZE2.
(ZE2) (S2CLNSM6CZ2) env-usage audit items D-3 / C2 / C4 / C1 applied on ZEROENV.

L2RPN AI4REALNET 2026 -- submission agent  (v5 + P2/P3/P4 + P5 per-switch screen + P6 DC bus-split screen)
=====================================================================================================
Every addition is behind its own CONFIG flag. Turn them all off -> byte-for-byte v5.

  P2  online forecast-error correction (LJN-style por_error).            -> USE_POR_CORR
  P3  safe-state economic layer (de-curtail / relax redispatch / SoC).   -> USE_SAFE_ECON
  P4  eager return-to-reference (unwind a stale split first).            -> USE_RECOVER_REF
  P5  per-SWITCH LODF screen (rank the switch by the cables IT moves).    -> USE_SWITCH_SCREEN
  P6  DC BUS-SPLIT SENSITIVITY screen (exact DC topology effect via a rank-2 Woodbury update of the
      cached base inverse; ranks the candidate pool by the TRUE post-split loading rather than a
      single-cable LODF proxy, WITHOUT calling predict()).               -> USE_SPLIT_SCREEN

  P6 math (validated against brute-force re-solve to 1e-12):
      Splitting substation s moves a group B of elements to the (empty) bus-2 node s' = s + n_sub.
      Each moved branch's incidence changes a_k -> a_k + u with u = e_{s'} - e_s (same for all).
      The DC susceptance update is rank-2 (+ a rank-1 strip of the empty-node placeholder):
          dB' = g u^T + u g^T + beta u u^T - e_{s'} e_{s'}^T ,  g = sum_k b_k a_k ,  beta = sum_k b_k
      theta_new = Woodbury(Z = (B'_R)^-1 cached, U=[u,g,e_{s'}], C=[[beta,1,0],[1,0,0],[0,0,-1]]) p_new
      Predicted loading anchored on the true AC base: rho ~ sqrt((P0 + dP_DC)^2 + Q0^2)/Slim.

Target image (codabench docker, Python 3.13):
  grid2op 1.12.2 | lightsim2grid 0.13.1 | cvxpy 1.9.1 | highspy 1.14.0 | scipy 1.16.3 | numpy 2.3.5
"""
import numpy as np, time
from collections import defaultdict
from grid2op.Agent import BaseAgent

# ===================== CONFIG  (tune the top groups; the bottom group is rarely touched) =====================
# --- SECURITY THRESHOLDS (the two main dials) ---
# --- (S2) NAMED THRESHOLDS: every limit on the S2 decision path comes from these names (set once, here) ---
NL = 0.99               # (S2) normal-line threshold: a line whose overflow counter is NOT running must stay below this
OL = 0.90               # (S2) overload-line threshold: a line whose overflow counter runs must get below this
N1 = 1.85               # (S2) N-1 threshold: worst loading allowed after losing one credible line (hard trip at 2.0)
RESTORE_SWITCH = 0.95   # (S2) Phase B: do-nothing corrected worst loading above this -> restore for the LOWEST worst loading
BASE_LIMIT  = NL               # (S2) was 0.99   # base case : "overloaded now" if rho > this. 0.95 keeps margin below the 1.0 soft trip
N1_LIMIT    = N1               # (S2) was 1.85   # N-1       : after a credible attack/maintenance, insecure if loading > this (< 2.0: hard trip)
                              #   so Q-heavy cables aren't invisible to the LODF pool. Heuristic (LPP is a P-factor);
                              #   reorders the pool only. False = bank-identical; flip to True in its own sweep.
# --- IDLE FAST-PATH (v3) ---
FASTPATH_RHO = NL              # (S2) was 0.99   # CHEAP secure gate: if every base flow < this AND no overflow AND no imminent maintenance -> skip all physics + N-1
# --- MULTI-AREA ACTION (v4): rules allow 1 substation + 1 line change PER AREA per step (3 areas) ---
VERIFY_PER_AREA = 40            # multi-area Stage 1: top switches exact-verified per overloaded area   # (V10) was 5   # (V20) was 10   # (V40P40) was 20   # (FAST) (S1UHF) was 40   # (S2) (S2B6v2F) was 10
RECO_CAP        = 100          # aggressive reconnection: re-energise a downed line if result keeps worst loading < this

STORAGE_COST = 10.0            # EUR / MWh absorbed or produced (competition value); energy = |power| * dt
# --- THREAT MODEL ---
MAINT_HORIZON = 12             # treat a line as a contingency if its planned maintenance starts within this many steps (~1h)
# --- HOW MANY THINGS TO LOOK AT (bigger = more thorough, slower) ---
N_CONT      = 2                # caps the N-1 (contingency,line) target pairs that drive the substation screen
PANIC_FACTOR = 1               # PANIC search multiplier for Stage-1 verifies + Stage-2 TOPK   # (BASE) was 2
PANIC_POOL_FACTOR = 2          # PANIC pool multiplier for SUB_TOPK / screen caps   # (BASE) was 3   # (B2PP2) was 1
PANIC_OVFL_COUNTER = 1         # (NEW) PANIC arms ONLY when some line's timestep_overflow >= this.
                               #       1 = any line counting; set very high (99) to disable panic entirely.
# --- WHEN TO ACT / WHICH SWITCHES ---
MIN_GAIN    = 1e-4             # act only if it lowers the worst normalized loading by >= this vs do-nothing   # (K2MG3) was 0.01   # (K4MG4) was 0.03   # (S1) (S1US) was 0.04   # (FIX1) noise guard, was 0.0
# --- MILP INTERNALS (rarely change: these encode  base >> N-1 >> cost >> switching) ---
W_BASE, W_N1, W_CUR, W_SW = 1e5, 1e3, 50.0, 5.0
FIX1_ON = True   # (FIX1) (S1UF) the verified flow fixes (build_fix1.py)
CA_ON = True   # (CA3) (M15CA) last three screens   # (CA2) (M14CA) complete: every stage   # (CA) (M13CA) the per-line forecast-error correction is added to EVERY predicted loading (all stages and gates)
_CA_NOW = [np.zeros(0)]   # (CA) this step's corr vector, set in decide()
def _cx(v):   # (CA) predicted next-step loading + this step's per-line correction
    v = np.asarray(v, dtype=float); c = _CA_NOW[0]
    return (v + c) if (CA_ON and c.shape == v.shape) else v
S2_SCORE = 'M6'         # (S2) how candidates are COMPARED (never whether they clear): 'M0' the source score, 'M1' urgency-weighted violations, 'M6' expected trip-equivalents   # (S2) (S2B6v2F) was 'M0'
M1_W0, M1_W1, M1_W2 = 1.0, 3.0, 10.0   # (S2 M1) violation weights for counter 0 / 1 / 2+ (build_fix1b.py M1)
S2_M6_SIGMA = 0.03              # (S2 M6) sigma of a line's corrected loading
S2_M6_W = (0.15, 0.40, 1.0)     # (S2 M6) weight of P(rho > 1) for counter 0 / 1 / 2+
S2_M6_M = (1.5, 1.5, 0.0)       # (S2 M6) weight of the expected exceedance E[(rho - 1)+] for counter 0 / 1 / 2+
S2_M6_WN1 = 0.1                 # (S2 M6) weight of the N-1 term
S2_M6_SHIFT = 1                 # (S2 v2 M6) weight index = clip(counter - S2_M6_SHIFT, 0, 2): grid2op trips a line when its protection
                                #   counter exceeds NB_TIMESTEP_OVERFLOW_ALLOWED = 3, i.e. an observed counter 3 still overloaded next
                                #   step; the study's weights assumed a trip on reaching 3.  0 = v1 (index = min(counter, 2))
S2_LA_PER_AREA = 3      # (S2) line actions kept per area, pooled over the topologies T0 / T1 / T2
S2_SUBCAP = 0           # (S2 feature b) at most this many configs per substation in each area's shortlist (0 = off)
S2_LETHAL_MAP = {58: ('62_63_160', '62_58_180'), 91: ('88_91_33',), 18: ('29_37_117',), 22: ('29_37_117',), 48: ('29_37_117',), 99: ('29_37_117',)}   # (LETHAL) substation with an element on bus 2 -> lines whose loss islands the grid (replay-confirmed)
S2_LETHAL_BAR = 0.0     # (LETHAL) post-outage bar for a lethal contingency in own-threshold units (0 = the standard N-1 bar); e.g. 1.5 like KLB
S2_MNTD_W = 6            # (MNTD) certain-outage countdown window   # (MNTD) (S2CMNTD6C) was 5
S2_MNTD_MAX = 2          # (MNTD) maximum scheduled lines in one shadow grid
S2_MNTD_BAR = 1.0        # (MNTD) post-outage own-threshold bar
S2_MNTD_OPTS = 10        # (MNTD) maximum LP options
S2_MNTD_CUR_MAX = 1.0    # (MNTD) current-grid exact safety bar   # (MNTD) (S2CMNTD6C) was 2.0
S2_MNTD_MAXSTEP = 3      # (MNTD) commits per certain outage
S2_RESTORE_NORAISE = True   # (NORAISE) (S2C) Phase B above RESTORE_SWITCH: a combination must not raise do-nothing's worst loading   # (NORAISE) (S2C) was False
S2_STOP_M = 0.10         # (STOP) (S2B6S10v2) best-of-all stops at a clear with every line <= (1 - this) x own threshold ...   # (STOP) (S2B6S10v2) was 0.0
S2_STOP_N1M = 0.30       # (STOP) ... and raw worst N-1 <= N1 - this (S2_STOP_M = 0: off)   # (STOP) (S2B6S10v2) was 0.0
S2_LP_OBJ = 'M6PWL'       # (LP) 'OLD' = the old MILP's weights (W_BASE / W_N1 / cost / W_CUR / W_STO, SLK rule); 'M6PWL' = piecewise-linear M6-like   # (LP) (S2CLPM) was 'OLD'
S2_LP_T0 = 1            # (LP) G1 size (0/1): T0 = do-nothing + prefix (dispatch only)
S2_LP_KCOMBO = 1        # (LP) G2 size: the best-scored COMBO combinations (>= 2 line actions)
S2_LP_KEX = 3           # (LP) G3 size: the best by exact M6 key among Stage 1 / MULTI / COMBO pairs
S2_LP_KLA = 3           # (LP) G4 size: the best line-action pairs by LP-screen value (own sensitivities, own exact loading)
S2_LP_KSP = 2           # (LP) G5 size: the best Stage 1 / MULTI by LP-screen value (never filled across groups)
S2_LP_MAX = None        # (LP) total cap on the options (None = the sum of the group sizes: no cap); the first ones in group order are kept
S2_LP_CHECK_N = 10      # (LP) only the best this many plans by LP objective (ties: the option's lower exact M6 key) get the exact check; the rest are dropped
LP_SPLIT_POOL = 8       # (LP) G5 pool: the best this many Stage 1 / MULTI by exact key are prepped (+ any already prepped)
LP_TB_EPS = 1e-3        # (LP) tie-break EUR/MW: column j of the fixed layout costs LP_TB_EPS (1 + j/n) more -> a unique MW vector
LP_OLD_SCALE = 1e-3     # (LP) OLD objective scale (conditioning; the judged design's value)
LP_M6_SCALE = 100.0     # (LP) M6PWL objective scale
LP_W1 = 1.0             # (LP) M6PWL: per unit of loading above the line's own threshold (NL, or OL if its counter runs)
LP_S1_MARGIN = 0.0      # (LP) M6PWL: the LP_W1 row's threshold is (own threshold - this); 0 = the spec
LP_W2_K0 = 2.0          # (LP) M6PWL: per unit above 1.0, M6 class 0 (class = clip(counter - S2_M6_SHIFT, 0, 2): counter 0-1 in v2)
LP_W2_K1 = 8.0          # (LP) M6PWL: ... class 1 (counter 2 in v2)
LP_W2_K2 = 30.0         # (LP) M6PWL: ... class 2 (counter 3 in v2: grid2op trips when the counter goes ABOVE 3 -> certain trip)
LP_W3 = 1000.0          # (LP) M6PWL: per unit above 2.0 (hard overflow threshold)
LP_WN1 = 0.1            # (LP) M6PWL: per unit of a contingency's worst post-contingency loading above its bar
LP_WCOST = 2e-5         # (LP) M6PWL: EUR/MW -> objective (cost_per_MW, W_CUR, STORAGE_COST x dt)
LP_RND_MW = 0.01        # (LP) the plan is rounded to this (MW) and clipped to its bounds
LP_EMIT_RD = 0.1        # (LP) redispatch entries below this (MW) are not sent
LP_EMIT_CUR = 0.5       # (LP) curtailment below this (MW) is not sent
LP_EMIT_STO = 0.1       # (LP) storage setpoints below this (MW) are not sent
LP_ITER_CAP = 20000     # (LP) HiGHS simplex iteration cap (deterministic work cap; NEVER time_limit / threads)
assert S2_SCORE in ('M0', 'M1', 'M6'), S2_SCORE
import math as _s2_math, traceback as _s2_tb
_s2_erf = np.vectorize(_s2_math.erf, otypes=[float])
def _s2_Phi(x):   # (S2 M6) standard normal CDF from math.erf (no scipy)
    return 0.5 * (1.0 + _s2_erf(np.asarray(x, dtype=float) / _s2_math.sqrt(2.0)))
def _s2_phi(x):   # (S2 M6) standard normal density
    x = np.asarray(x, dtype=float); return np.exp(-0.5 * x * x) / _s2_math.sqrt(2.0 * _s2_math.pi)
S2_DIAG = {}      # (S2) print-only counters; no decision ever reads them
def _s2_cnt(k, n=1): S2_DIAG[k] = S2_DIAG.get(k, 0) + n
def _s2_steplog(): return False   # (ZEROENV) debug print switch, no OS-environment read
def _s2_estlog(): return False   # (ZEROENV) debug print switch, no OS-environment read
W_BASE_SEL, W_N1_SEL = 100.0, 1.0
NWT_ITERS          = 5       # (NWT) Newton iterations cap
NWT_TOL            = 1e-2    # (NWT) Newton tolerance
NWTEP_COUNTER      = 1       # (NWTEP) overflow counter threshold of the line   # (NWTEP1) was 2
NWTEP_MAX          = 400     # (NWTEP) at most this many extra configs per step   # (FAST) (S1UHF) was 400   # (S2) (S2B6v2F) was 100
N1_DIVERGE_BASE    = 2.0
N1_DIVERGE_STEP    = 1.0
N1_INCLUDE  = 1.0
TN_SP_MON = (3, 4, 5)         # (TNsp) spring months with the softer post-trip bar
TRIP_N1_LIMIT_SP   = 0.95      # (TNsp)
TRIP_N1_LIMIT      = 0.85      # post-trip loading limit for these lines (attacks keep N1_LIMIT = 1.8)   # (TN90 on BR100)   # (J3PT85) was 0.90
SLK_MIN_COUNT      = 1       # (SLK) per-line MILP slack (sum of violations) only when at least this many lines are counting; scalar (worst) otherwise
# --- (v7) OBSERVATION-ONLY attack-end handling (replaces the v6.1 live-env gate; reads NOTHING from env) ---
# Published opponent parameters (starting-kit config.py): min duration 1h=12 steps, mean 2h=24, hard cap 96.
ATK_MIN_HOLD    = 12    # no reconnect attempt for this many steps after onset (the attack CANNOT end sooner)
ATK_PROBE_EVERY = 4     # afterwards: one reconnect probe per this many steps (a failed probe self-throttles via the 3-step line cooldown)
ATK_MAX_DUR     = 96    # opponent_attack_duration cap: past this the attack is CERTAINLY over -> stop tracking

# (v14) codabench ingestion hands make_agent a TEMPLATE env with no opponent configured -> _read_attackable
# returned [] and ALL attack machinery (credible tops, v7 tracker, gate) was silently OFF online.
# Fallback = the PUBLISHED starting-kit config.py `lines_attacked` (3 areas), mapped via env.name_line.
# (NOENV) (S2CLNSM6CNE) substation -> area map of the legal-action rule = the PUBLISHED kit config.py RulesByArea (same order);
# the agent no longer reads it from env._game_rules.
SUBS_BY_AREA = [
    [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31,
     70, 71, 72, 112, 113, 114, 116],
    [32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61,
     62, 63, 64, 65, 66],
    [67, 68, 69, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
     100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 115, 117],
]
ATTACK_LINES_FALLBACK = [
    ["26_31_106", "21_22_93", "17_18_88", "4_10_162", "12_14_68", "29_37_117"],
    ["62_58_180", "62_63_160", "48_50_136", "48_53_141", "41_48_131", "39_41_121",
     "43_44_125", "44_45_126", "34_35_110", "54_58_154"],
    ["74_117_81", "93_95_43", "88_91_33", "91_92_37", "99_105_62", "102_104_61"],
]

# ===================== NEW IMPROVEMENT DIALS (P2..P6) -- all default ON; set False to recover exact v5 ==========
# --- (P2) ONLINE FORECAST-ERROR CORRECTION (LJN-style por_error) ---
USE_POR_CORR    = True   # (v44_p2) ON for the validation emulator: inflate margins by observed forecast under-prediction
POR_CORR_ALPHA  = 0.75  # (AX2 sweep)
POR_CORR_CAP    = 0.1  # (AX2 sweep)
ECON_DECURTAIL_STEP = 0.1
ECON_SOC_DEADBAND   = 0.05
# (RXB, relax-workflow Enhancement B) BAND-RELAX: the calm-path cap 0.95 forbids relax commits in
# [0.95,0.99) - the idle band where 82%% of pre-death approach steps move zero MW. When the strict call
# returns None and rho is in the band, retry UNWIND-ONLY (no de-curtail, no SoC - the battery lesson)
# with the never-worsen gate. Arm ceil=0.97.
ECON_DECURT_MAX_RHO = 0.0    # A's stress cutoff OFF in the solo-B arms
SAFE_ECON_RHO       = 0.95
                             # setter p_t = max(cost[gen_p > 0]): turning such a unit on multiplies the bill
RETIRE_RAMP_FRAC   = 0.95    # hard fraction of the per-step ramp a single retire ask may use.  < 1 is
                             # MANDATORY: a composed action never reaches _check_for_ambiguity, so nothing
                             # downstream would reject an over-ramp ask
RETIRE_MIN_MW      = 1e-2    # per-generator dead band (the threshold the base uses on target_dispatch)
RETIRE_MIN_SUM_MW  = 0.0     # TOTAL dead band: 0.0 = fire on anything (donor value)
RETIRE_CONFIRM_TOL = 1e-3    # ledger promotion tolerance in MW: between float32 rounding on target_dispatch
                             # (~3e-5 at 500 MW) and the smallest possible ask (1e-2)
RETIRE_MAX_GENS    = 1e9     # BUDGET -- never caps
ECON_SAFE_TOL      = -1.0   # (NG) never-worsen gate OFF, was 0.05; (E4S) on the SAFE path an economic commit may not raise the worst loading by
RAMPGUARD_MW        = 20.0   # (RAMPGUARD) fixed margin (MW) for the real-vs-forecast mismatch
RAMPGUARD_REN_FRAC  = 0.05   # (RAMPGUARD) + this fraction of the renewable output now
RAMPGUARD_MIN_F     = 0.05   # (RAMPGUARD) below this scale the economic step is skipped
RAMPGUARD_DIAG      = dict(calls=0, scaled=0, dropped=0, fsum=0.0)
ECON_RELAX_TOL      = 9.0   # (NG) never-worsen at the relaxed-band call OFF, was 0.010
# --- (P5) PER-SWITCH LODF SCREEN (used only when USE_SPLIT_SCREEN=False) ---
USE_SWITCH_SCREEN = True
SWITCH_PREP_CAP   = 40          # 2.74x on ch4 (840 -> 319 predicts) and mean-rho IMPROVED 0.9211 -> 0.9152   # (V20) was 15   # (V40P40) was 20   # (FAST) (S1UHF) was 40   # (S2) (S2B6v2F) was 10
BA_SECURE         = 1
PREP_FLOOR        = 3
                                 # further prep is waste. Note this counts EXACT ba/wn (from the AC predict),
                                 # unlike PREP_FLOOR which counts DC-secure candidates -- and the DC is
                                 # unreliable for splits. 0 = off. Never applies in PANIC.
# --- (P6) DC BUS-SPLIT SENSITIVITY SCREEN (OVERRIDES the other screens; LODF is only a coarse pool) ---
USE_SPLIT_SCREEN  = True
SPLIT_POOL_MULT   = 10           # coarse LODF pool = SWITCH_PREP_CAP * this ; the DC re-rank keeps the best SWITCH_PREP_CAP
WPG_PER_SUB = 3   # (FAST) (S1UHF) was 3   # (S2) (S2B6v2F) was 1
SPLIT_COND_MAX    = 1e8         # (P6 guard) if base B'_R or a candidate 3x3 Woodbury S is worse-conditioned than this, DC is UNTRUSTED -> LODF fallback
SPLIT_BA_CAP      = 100.0         # (P6 guard) a DC-predicted loading above this is a blow-up -> LODF rank, never trusted as a number
FCFIX_BAND  = 0.25         # (FCFIX) forecast conv total outside 1 +/- this x current conv total = garbage
FCFIX_DIAG  = dict(calls=0, steps=0, horizons=0, errors=0)

def _cl_fcfix(self, obs):
    d = FCFIX_DIAG; d['calls'] += 1
    try:
        fi = getattr(obs, '_forecasted_inj', None)
        if not fi or len(fi) < 2: return 0
        ren = np.asarray(obs.gen_renewable, bool); gp = np.asarray(obs.gen_p, float)
        cur = float(gp[~ren].sum())
        if not np.isfinite(cur) or cur <= 1.0: return 0
        cur_load = float(np.asarray(obs.load_p, float).sum()); cur_ren = float(gp[ren].sum())
        off = cur_load - cur_ren - cur
        n = 0; ratios = []; own = False
        for h in range(1, len(fi)):
            item = fi[h][1] if isinstance(fi[h], (tuple, list)) and len(fi[h]) > 1 else fi[h]
            inj = item.get('injection', item) if isinstance(item, dict) else None
            if not isinstance(inj, dict) or 'prod_p' not in inj: continue
            pp = np.asarray(inj['prod_p'], float)
            if pp.shape != gp.shape: continue
            tot = float(np.nansum(pp[~ren]))
            if tot > 0.0 and abs(tot / cur - 1.0) <= FCFIX_BAND: continue
            lp = float(np.nansum(np.asarray(inj['load_p'], float))) if 'load_p' in inj else cur_load
            rp = float(np.nansum(pp[ren]))
            scale = (lp - rp - off) / cur
            if not np.isfinite(scale): scale = 1.0
            scale = min(max(scale, 0.7), 1.3)
            newpp = pp.copy(); newpp[~ren] = gp[~ren] * scale
            if not own:   # (NOENV) this observation's own list: never edit the env-shared dicts
                fi = list(fi); obs._forecasted_inj = fi; own = True
            item = {k: (dict(v) if isinstance(v, dict) else v) for k, v in item.items()}
            inj = item['injection'] if 'injection' in item else item
            fi[h] = (fi[h][0], item) if isinstance(fi[h], (tuple, list)) and len(fi[h]) > 1 else item
            inj['prod_p'] = newpp.astype(np.asarray(inj['prod_p']).dtype)
            n += 1; ratios.append((h, round(tot / cur, 2), round(scale, 3)))
        if n:
            d['steps'] += 1; d['horizons'] += n
            if d['steps'] <= 60: print('FCFIX step=%d repaired=%d %s' % (int(obs.current_step), n, ratios[:4]), flush=True)
        return n
    except Exception as exc:
        d['errors'] += 1
        if d['errors'] <= 3: print('FCFIX error', repr(exc), flush=True)
        return 0

                          # sparse grid is how you island -- this is the inverted gate. Sweep it.

                           #   agent is holding down -- bare AND composed with the top splits. A CLEARING one
                           #   commits at once. Costs nothing when no line is down.
RECO_RELIEF_CAP  = 8       # max down-lines to prep (1 AC solve + LODF build each)

                         #   exceeds max(do-nothing N-1, N1_LIMIT) + this. Kills the regressions where a config
                         #   survived the first trip (good cascade score) but was N-1-fragile and died elsewhere.
# ============================================================================================================
# ============================================================================================================


class _RuleLimits:
    """(ZEROENV) the two public game-rule limits the legality check needs, copied once at construction."""
    def __init__(self, max_line, max_sub):
        self.MAX_LINE_STATUS_CHANGED = max_line; self.MAX_SUB_CHANGED = max_sub


class _GridDesc:
    """(ZEROENV) Everything the agent takes from make_agent's env, taken ONCE in __init__: its own action-space copy
    (BaseAgent deep-copies env.action_space) and the two public rule limits. Static grid descriptors (ids, positions,
    names, generator / storage specs) are class attributes of that action space; arrays are returned as private copies.
    The agent keeps no reference to the env."""
    def __init__(self, action_space, parameters):
        self.action_space = action_space
        self.parameters = _RuleLimits(int(parameters.MAX_LINE_STATUS_CHANGED), int(parameters.MAX_SUB_CHANGED))
    def __getattr__(self, name):
        if name.startswith('__'): raise AttributeError(name)
        v = getattr(type(self.action_space), name)
        return v.copy() if isinstance(v, np.ndarray) else v


class MyAgent(BaseAgent):
    """118-bus preventive controller: RECONNECT -> TRIGGER + SCREEN -> MULTI-AREA Stage 1 -> SF Stage 2 MILP.
    Linear LODF/SF (and the DC split screen) only screen+rank; EXACT AC makes every actual decision."""

    def __init__(self, env):
        BaseAgent.__init__(self, action_space=env.action_space)
        self.gd = gd = _GridDesc(self.action_space, env.parameters)   # (ZEROENV) no env handle is kept
        # ---- one-time setup ----
        self.ns, self.nl = gd.n_sub, gd.n_line
        self.or_sub, self.ex_sub = gd.line_or_to_subid, gd.line_ex_to_subid
        self.or_pos, self.ex_pos = gd.line_or_pos_topo_vect, gd.line_ex_pos_topo_vect
        self.gen_sub, self.gen_pos = gd.gen_to_subid, gd.gen_pos_topo_vect
        self.load_sub, self.load_pos = gd.load_to_subid, gd.load_pos_topo_vect
        self.do_nothing = gd.action_space({})
        all_splits = list(gd.action_space.get_all_unitary_topologies_set(gd.action_space))
        self.pos2sub = np.repeat(np.arange(self.ns), gd.sub_info)
        self.incident = {s: [k for k in range(self.nl) if self.or_sub[k] == s or self.ex_sub[k] == s] for s in range(self.ns)}
        self.trips = [gd.action_space({"set_line_status": [(k, -1)]}) for k in range(self.nl)]
        self.ru, self.rd = gd.gen_max_ramp_up, gd.gen_max_ramp_down
        self.pmin, self.pmax, self.cost = gd.gen_pmin, gd.gen_pmax, gd.gen_cost_per_MW
        self.Rgen = [g for g in range(gd.n_gen) if gd.gen_redispatchable[g]]
        self.BY_SUB = defaultdict(list)
        for c in all_splits:
            self.BY_SUB[self.sub_of(c)].append(c)
        # ---- (v5) storage characteristics ----
        self.n_storage = int(gd.n_storage)
        if self.n_storage > 0:
            self.storage_sub = np.asarray(gd.storage_to_subid, dtype=int)
            self.storage_pos = np.asarray(gd.storage_pos_topo_vect, dtype=int)
            self.P_prod   = np.asarray(getattr(gd, "storage_max_p_prod",   np.zeros(self.n_storage)), dtype=float)
            self.P_absorb = np.asarray(getattr(gd, "storage_max_p_absorb", np.zeros(self.n_storage)), dtype=float)
            self.Emax     = np.asarray(getattr(gd, "storage_Emax",         np.zeros(self.n_storage)), dtype=float)
            self.Emin     = np.asarray(getattr(gd, "storage_Emin",         np.zeros(self.n_storage)), dtype=float)
        else:
            self.storage_sub = self.storage_pos = np.array([], dtype=int)
            self.P_prod = self.P_absorb = self.Emax = self.Emin = np.array([], dtype=float)
        # ---- attackable lines per area ----
        self.attack_by_area = self._read_attackable(gd)
        self.attackable = sorted({k for area in self.attack_by_area for k in area})
        # ---- NEW ----
        # ---- substation -> area map ----
        self.sub_area = np.full(self.ns, -1, dtype=int)
        try:
            sba = SUBS_BY_AREA   # (NOENV) published config, not env._game_rules
            vals = sba.values() if hasattr(sba, "values") else sba
            for a, subs_ in enumerate(vals):
                for s in subs_:
                    si = int(s)
                    if 0 <= si < self.ns:
                        self.sub_area[si] = a
        except Exception:
            pass
        # ---- (P5/P6) per-config screen precompute: substation, cables moved to bus 2, and moved gens/loads/storage ----
        self._scr_cfg = all_splits
        _n_cfg = len(all_splits); _maxw = 1; _moved = []; _subs = []
        for c in all_splits:
            s = int(self.sub_of(c)); sb = c.set_bus
            _subs.append(s)
            mv = [k for k in self.incident[s] if sb[self.or_pos[k]] == 2 or sb[self.ex_pos[k]] == 2]
            _moved.append(mv); _maxw = max(_maxw, len(mv))
        self._scr_sub = np.array(_subs, dtype=int)
        self._scr_idx = np.full((_n_cfg, _maxw), -1, dtype=int)   # padded line-ids moved to bus 2 (-1 = pad)
        for i, mv in enumerate(_moved):
            if mv: self._scr_idx[i, :len(mv)] = mv
        _gat = defaultdict(list); _lat = defaultdict(list); _sat = defaultdict(list)
        for gi in range(gd.n_gen): _gat[int(self.gen_sub[gi])].append(gi)
        for li in range(gd.n_load): _lat[int(self.load_sub[li])].append(li)
        for si in range(self.n_storage): _sat[int(self.storage_sub[si])].append(si)
        self._scr_gen2 = []; self._scr_load2 = []; self._scr_sto2 = []
        for idx, c in enumerate(all_splits):
            sub = int(self._scr_sub[idx]); sb = c.set_bus
            self._scr_gen2.append(np.array([gi for gi in _gat.get(sub, []) if sb[self.gen_pos[gi]] == 2], dtype=int))
            self._scr_load2.append(np.array([li for li in _lat.get(sub, []) if sb[self.load_pos[li]] == 2], dtype=int))
            self._scr_sto2.append(np.array([si for si in _sat.get(sub, []) if self.n_storage > 0 and sb[self.storage_pos[si]] == 2], dtype=int))
        self._scr_ref = np.array([bool(np.all(np.asarray(c.set_bus)[np.asarray(c.set_bus) != 0] == 1)) for c in all_splits], dtype=bool)   # (S2) the reference (all bus 1) config of a substation: a no-op if unsplit, a re-mesh if split
        # ---- (P2) online forecast-error correction state + (P6) DC self-check accumulators ----
        self._fc_rho_prev = None
        self._rho_corr = np.zeros(self.nl)
        # ---- (v7) observation-only attack tracker: reconnect a line only once ITS OWN attack is over ----
        self._atk_now = np.zeros(self.nl, dtype=bool)     # True = hold this line DOWN (no reconnect attempt this step)
        self._atk_set = set(int(k) for k in self.attackable)
        self._atk_onset = np.full(self.nl, -1, dtype=np.int64)        # step at which the line's attack was detected
        self._atk_probe = np.full(self.nl, -(10**9), dtype=np.int64)  # step of its last reconnect probe
        self._prev_ls = None
        self._atk_probe_due = []                                       # (v7.1) lines whose probe rider goes out this step
        self._econ_asked = np.zeros(int(gd.n_gen), dtype=bool)        # (P6) gens the env has CONFIRMED we asked
        self._econ_pend = {}                                           # (P6) gen -> target_dispatch we expect next step
        print("agent ready | env %s | %d sub %d line %d gen %d storage | %d candidates / %d subs | attackable %d lines / %d areas | P2=%s P3=%s P4=%s P5=%s P6=%s"
              % ("?", self.ns, self.nl, gd.n_gen, gd.n_storage,
                 len(all_splits), len(self.BY_SUB), len(self.attackable), len(self.attack_by_area),
                 USE_POR_CORR, False, False, USE_SWITCH_SCREEN, USE_SPLIT_SCREEN), flush=True)

    @staticmethod
    def _read_attackable(gd):
        by_area = []                                   # (NOOPP) the opponent object is NEVER inspected: the
        if not by_area:                                # attackable lines come only from the PUBLISHED kit config.py
            try:
                n2i = {str(n): i for i, n in enumerate(gd.name_line)}
                by_area = [a for a in ([n2i[n] for n in area if n in n2i]
                                       for area in ATTACK_LINES_FALLBACK) if a]
            except Exception:
                by_area = []
        return by_area

    # ===================== helper methods (identical to v4/v5) =====================
    def sub_of(self, a):
        pos2sub = self.pos2sub
        p = np.where(a.set_bus != 0)[0]; return int(pos2sub[p[0]]) if len(p) else -1

    def _ll(self, o):
        or_sub, ex_sub, or_pos, ex_pos, ns, nl = self.or_sub, self.ex_sub, self.or_pos, self.ex_pos, self.ns, self.nl
        orb = or_sub + (o.topo_vect[or_pos] - 1) * ns; exb = ex_sub + (o.topo_vect[ex_pos] - 1) * ns
        return np.array([[int(orb[l]), int(exb[l])] for l in range(nl)])

    def _gbbp(self, Y):
        G = Y.real.copy(); B = Y.imag.copy(); Bp = B.copy()
        for i in range(Y.shape[0]): Bp[i, i] = -(B[i, :].sum() - B[i, i])
        for i in np.where(np.abs(Y).sum(1) < 1e-9)[0]: G[i, i] = B[i, i] = Bp[i, i] = 1.0
        return G, B, Bp

    def _fixedV(self, o):
        gen_sub, gen_pos, ns = self.gen_sub, self.gen_pos, self.ns
        gb = set(int(gen_sub[i] + (o.topo_vect[gen_pos[i]] - 1) * ns) for i in range(len(gen_sub))); return np.array(sorted({0} | gb))

    def _redM(self, G, B, Bp, fV):
        nB = G.shape[0]; kP = np.setdiff1d(np.arange(nB), [0]); kQ = np.setdiff1d(np.arange(nB), fV)
        return np.block([[(-Bp)[np.ix_(kP, kP)], G[np.ix_(kP, kQ)]], [(-G)[np.ix_(kQ, kP)], (-B)[np.ix_(kQ, kQ)]]]), kP, kQ

    def flowsens(self, Y, ll, Bp=None):
        nl = self.nl
        G = Y.real; B = Y.imag
        if Bp is None: Bp = self._gbbp(Y)[2]
        nB = Y.shape[0]
        Gij = np.zeros((nl, nB)); Bpij = np.zeros((nl, nB)); Bij = np.zeros((nl, nB))
        for k, (i, j) in enumerate(ll):
            g = -G[i, j]; bp = -Bp[i, j]; b = -B[i, j]; Gij[k, i], Gij[k, j] = g, -g; Bpij[k, i], Bpij[k, j] = -bp, bp; Bij[k, i], Bij[k, j] = -b, b
        return Gij, Bpij, Bij

    def worstN1_exact(self, state, cred):
        """Worst post-contingency loading over the credible set. (v24) With SCORE_AGG_SUM it returns
        N1_LIMIT + (the worst contingency's TOTAL violation summed over lines) instead of the single worst
        rho -- note the two AGREE exactly when only one line is over 1.85, so `< N1_LIMIT` keeps meaning
        'no N-1 violation' either way."""
        trips = self.trips
        _T = self.__dict__.setdefault('_T', {}); _T['n1_calls'] = _T.get('n1_calls', 0) + 1; _T['n1_predicts'] = _T.get('n1_predicts', 0) + len(cred)   # (TIME)
        onL = np.where(state.line_status)[0]; sim = state.get_simulator()
        m = 0.0; ndiv = 0; agg = 0.0; mraw = 0.0   # (S2) mraw = the RAW worst post-contingency loading (no per-contingency rescale)
        self._n1_stash = {}   # (LP) contingency -> exact post-contingency (p_or, q_or, rho, line_status); read by the LP layer only
        for k in cred:
            r = sim.predict(trips[k], do_copy=True)   # (N1S) true N-1 in summer only
            if getattr(r, "converged", False):
                _rk = _cx(r.current_obs.rho)[onL[onL != k]]   # (CA)
                _o = r.current_obs; self._n1_stash[int(k)] = (np.array(_o.p_or, dtype=float), np.array(_o.q_or, dtype=float), np.array(_o.rho, dtype=float), np.array(_o.line_status, dtype=bool))
                _lk = float((getattr(self, '_n1lim', None) or {}).get(int(k), N1_LIMIT))   # (KLB) this contingency's own bar
                m = max(m, float(_rk.max()) * (N1_LIMIT / _lk))
                mraw = max(mraw, float(_rk.max()))   # (S2)
                agg = max(agg, float(np.clip(_rk - _lk, 0.0, None).sum() * (N1_LIMIT / _lk)))   # (KLB) violation vs ITS bar, rescaled to the 1.85 basis
            else:
                ndiv += 1                             # this contingency ISLANDS the grid
                self._n1_ndiv = 1; self._n1_raw = 9.99   # (S2) islanding sentinel
                return 9.99                       # (v19) flat sentinel, stop early
        self._n1_ndiv = ndiv; self._n1_raw = mraw   # (S2) read by the M6 score; the return value is unchanged
        if ndiv:
            return max(m, N1_DIVERGE_BASE + N1_DIVERGE_STEP * ndiv)   # (v23) graded: more islanding = strictly worse
        if agg > 0.0:
            return N1_LIMIT + agg
        return m

    def _bridges_from_buses(self, line_status, bor, bex):
        adj = defaultdict(list)
        for k in range(self.nl):
            if bool(line_status[k]):
                a, b = int(bor[k]), int(bex[k])
                if a != b:
                    adj[a].append((b, k)); adj[b].append((a, k))
        disc = {}; low = {}; bridges = set(); t = [0]
        def dfs(u, pe):
            disc[u] = low[u] = t[0]; t[0] += 1
            for v, ke in adj[u]:
                if ke == pe: continue
                if v not in disc:
                    dfs(v, ke)
                    if low[v] < low[u]: low[u] = low[v]
                    if low[v] > disc[u]: bridges.add(ke)
                elif disc[v] < low[u]:
                    low[u] = disc[v]
        for n in list(adj.keys()):
            if n not in disc: dfs(n, -1)
        return bridges

    def _bridge_lines(self, o):
        bor = self.or_sub + (o.topo_vect[self.or_pos] - 1) * self.ns
        bex = self.ex_sub + (o.topo_vect[self.ex_pos] - 1) * self.ns
        return self._bridges_from_buses(o.line_status, bor, bex)

    def _new_bridges_of_set_bus(self, c, topo_vect, line_status, base_bridges):
        tv = topo_vect.copy(); sb = c.set_bus; m = sb != 0; tv[m] = sb[m]
        bor = self.or_sub + (tv[self.or_pos] - 1) * self.ns
        bex = self.ex_sub + (tv[self.ex_pos] - 1) * self.ns
        return self._bridges_from_buses(line_status, bor, bex) - base_bridges

    
    def _remesh_action(self, obs, s):
        """Re-mesh substation s to bus 1, but LEAVE the endpoint of any incident line that is on
        cooldown OR currently disconnected untouched (set_bus 0) -- switching such a line's bus is
        the IllegalAction. Returns a grid2op action, or None if nothing legal is left to re-mesh."""
        sbv = np.zeros(len(obs.topo_vect), dtype=int)
        sbv[self.pos2sub == s] = 1
        for k in self.incident[s]:
            if obs.time_before_cooldown_line[k] != 0 or not bool(obs.line_status[k]):
                sbv[self.or_pos[k] if self.or_sub[k] == s else self.ex_pos[k]] = 0
        if not np.any(sbv == 1):
            return None
        try:
            return self.gd.action_space({"set_bus": sbv})
        except Exception:
            return None

    def _mnt_strip(self, obs, a):
        """(v14 FIX) grid2op's obs.simulate lets an action that touches a line whose MAINTENANCE starts
        NEXT step CANCEL that maintenance in the forecast (phantom-keep), while the real env enforces it
        (proven: ch105 step 683 -> remesh claimed 0.83, reality islanded). Strip both bus ends and forbid
        reconnection of tnm==1 lines so every simulate and every commit is truthful. Early SHED (-1) stays."""
        mw = np.where(np.asarray(obs.time_next_maintenance, dtype=int) == 1)[0]
        if len(mw) == 0:
            return a
        tv = np.asarray(a._set_topo_vect); sl = np.asarray(a._set_line_status)
        if (not np.any(tv[self.or_pos[mw]] != 0)) and (not np.any(tv[self.ex_pos[mw]] != 0)) and (not np.any(sl[mw] > 0)):
            return a                                       # action does not touch them -> no copy needed
        out = a.copy()
        out._set_topo_vect[self.or_pos[mw]] = 0
        out._set_topo_vect[self.ex_pos[mw]] = 0
        out._set_line_status[mw] = np.minimum(out._set_line_status[mw], 0)
        return out

    def _atk_strip(self, obs, a):
        """(FIX) base_sim.predict() does NOT enforce the opponent: a set_bus on an ATTACKED line's
        endpoint silently RECONNECTS it in the forecast and returns a fantasy grid. An attack leaves
        time_before_cooldown_line == 0, so legal() admits the attacked line's OWN substations, and
        every candidate there phantom-reconnects it. Measured ch204 @53 (136 down): 400/400 raw sub-48
        candidates reconnected 136 and scored gridmax 0.854 while the truth was 1.155 -- they OUTSCORE
        the real fix. fin() strips this at COMMIT, so the agent scores one action and commits another
        (predict 0.819 -> realized 1.162 -> cascade). Strip it at SCORING time too."""
        if not self._atk_now.any():
            return a
        aw = np.where(self._atk_now)[0]
        tv = np.asarray(a._set_topo_vect); sl = np.asarray(a._set_line_status)
        if (not np.any(tv[self.or_pos[aw]] != 0)) and (not np.any(tv[self.ex_pos[aw]] != 0)) and (not np.any(sl[aw] > 0)):
            return a                                       # action does not touch them -> no copy needed
        out = a.copy()
        out._set_topo_vect[self.or_pos[aw]] = 0
        out._set_topo_vect[self.ex_pos[aw]] = 0
        out._set_line_status[aw] = np.minimum(out._set_line_status[aw], 0)
        return out




    # ===================== (P3) safe-state economic layer =====================
    def _ramp_guard(self, obs, parts):   # (RAMPGUARD)
        """Scale the economic parts so that the next-step mismatch fits the dispatchable fleet's remaining ramp."""
        RAMPGUARD_DIAG['calls'] += 1
        gp = np.asarray(obs.gen_p, dtype=float); pmax = np.asarray(self.pmax, dtype=float); pmin = np.asarray(self.pmin, dtype=float)
        ru = np.asarray(self.ru, dtype=float); rd = np.asarray(self.rd, dtype=float)
        ren = np.asarray(obs.gen_renewable, dtype=bool)
        gpbc = getattr(obs, 'gen_p_before_curtail', None)
        rl = list(parts.get('redispatch', [])); cl = list(parts.get('curtail', [])); sl = list(parts.get('set_storage', []))
        # asked moves
        asked = {}
        for g, x in rl: asked[int(g)] = asked.get(int(g), 0.0) + float(x)
        E = float(sum(asked.values()))
        dec = 0.0
        for g, lim in cl:
            g = int(g); avail = float(gpbc[g]) if gpbc is not None else float(gp[g])
            dec += max(0.0, min(avail, float(lim) * float(pmax[g])) - float(gp[g]))
        E += dec
        sp_now = np.asarray(getattr(obs, 'storage_power', np.zeros(self.n_storage)), dtype=float) if self.n_storage > 0 else np.zeros(0)
        sw = 0.0
        for j, p in sl: sw += -(float(p) - float(sp_now[int(j)]))   # charging less / producing more = extra injection
        E += sw
        # natural forecast change (renewables up / loads down = the fleet must go down)
        fc = getattr(self, '_rg_fc', None); N = 0.0
        if fc is not None:
            try:
                N = float(np.asarray(fc.gen_p, dtype=float)[ren].sum() - gp[ren].sum()) - float(np.asarray(fc.load_p, dtype=float).sum() - np.asarray(obs.load_p, dtype=float).sum())
            except Exception:
                N = 0.0
        M = RAMPGUARD_MW + RAMPGUARD_REN_FRAC * float(gp[ren].sum())
        # fleet room after the asked moves, ON dispatchable units only
        Rd = 0.0; Ru = 0.0
        for g in self.Rgen:
            g = int(g)
            if float(gp[g]) <= 1e-6: continue
            x = asked.get(g, 0.0)
            Rd += max(0.0, min(float(rd[g]), float(gp[g] - pmin[g])) - max(0.0, -x))
            Ru += max(0.0, min(float(ru[g]), float(pmax[g] - gp[g])) - max(0.0, x))
        need = E + N
        f = 1.0
        if need > 0.0 and need + M > Rd:
            f = (Rd - M - N) / E if E > 1e-6 else 0.0
        elif need < 0.0 and -need + M > Ru:
            f = (Ru - M + N) / (-E) if E < -1e-6 else 0.0
        f = max(0.0, min(1.0, f))
        if f >= 1.0 - 1e-9: return parts
        if f < RAMPGUARD_MIN_F:
            RAMPGUARD_DIAG['dropped'] += 1; return {}
        RAMPGUARD_DIAG['scaled'] += 1; RAMPGUARD_DIAG['fsum'] += f
        out = {}
        if rl: out['redispatch'] = [(int(g), float(x) * f) for g, x in rl if abs(float(x) * f) > 1e-2]
        if cl:
            clim = getattr(obs, 'curtailment_limit', None)
            cc = []
            for g, lim in cl:
                cur = float(clim[int(g)]) if clim is not None else float(gp[int(g)] / max(pmax[int(g)], 1e-9))
                cc.append((int(g), float(min(1.0, cur + f * (float(lim) - cur)))))
            out['curtail'] = cc
        if sl: out['set_storage'] = [(int(j), float(sp_now[int(j)] + f * (float(p) - sp_now[int(j)]))) for j, p in sl]
        _stepno = int(getattr(obs, 'current_step', 0))
        if _stepno > 0 and _stepno % 288 == 0: print('RAMPGUARD', {k: (round(v, 2) if isinstance(v, float) else v) for k, v in RAMPGUARD_DIAG.items()}, flush=True)
        return {k: v for k, v in out.items() if v}
    def _safe_economic(self, obs, fin, ceil=None, no_decurtail=False, no_soc=False, stressed=False):
        """SAFE-state economy: de-curtail renewables, walk redispatch toward 0, steer SoC -> 50%.
        Committed only if a real simulate() keeps worst loading < SAFE_ECON_RHO with no new bridge."""
        gd = self.gd
        parts = {}
        _cur_now = float(np.asarray(obs.rho).max())
        if not no_decurtail and (not (ECON_DECURT_MAX_RHO > 0 and _cur_now >= ECON_DECURT_MAX_RHO)):
            gpbc = getattr(obs, "gen_p_before_curtail", None)
            clim = getattr(obs, "curtailment_limit", None)
            if gpbc is not None:
                cl = []
                for g in range(gd.n_gen):
                    if not bool(obs.gen_renewable[g]): continue
                    cur = float(clim[g]) if clim is not None else 1.0
                    if cur < 1.0 - 1e-3 and float(gpbc[g]) > float(obs.gen_p[g]) + 0.5:
                        cl.append((int(g), float(min(1.0, cur + ECON_DECURTAIL_STEP))))
                if cl: parts["curtail"] = cl
        td = np.asarray(obs.target_dispatch, dtype=float)
        # ---- the BASE target-keyed list, arithmetic untouched.  It is the FLOOR: U1 may only ever
        # ---- do MORE than the base unwind, never less.  (F10, found by measurement: with the dead
        # ---- band suppressing this list, idx 135 went C_redisp 2,235 -> 21,425 EUR, +858%.)
        act_gens = [g for g in self.Rgen if abs(td[g]) > 1e-2]
        rl = []
        if act_gens:
            f = 1.0
            for g in act_gens:
                ramp = self.ru[g] if td[g] < 0 else self.rd[g]
                if abs(td[g]) > 1e-9: f = min(f, float(ramp) / abs(td[g]))
            f = max(0.0, min(1.0, f))
            rl = [(int(g), float(-f * td[g])) for g in act_gens if abs(f * td[g]) > 1e-2]
        # (P6/U1) RETIRE.  The scorer charges |actual_dispatch| every step
        # (l2RPNSandBoxScore.py:69-74) and the env only self-heals generators in
        # _already_modified_gen (baseEnv.py:2290-2296 and the objective at :2408), so MW parked on
        # a generator this agent never asked is frozen for the rest of the episode.  Key the unwind
        # on ACTUAL and ask the ABSOLUTE correction, because baseEnv.py:2107-2113 does
        # target += ask for an already-modified generator but target = actual + ask for a
        # first-modified one.  One ramp per generator, never a single global factor: one large
        # target must not throttle every other retirement.
        ad = np.asarray(obs.actual_dispatch, dtype=float)
        gp = np.asarray(obs.gen_p, dtype=float)
        cst = np.asarray(self.cost, dtype=float)
        _onm = gp > 0.0
        pt = float(cst[_onm].max()) if bool(_onm.any()) else 0.0   # the scorer's p_t for THIS step
        am = self._econ_asked
        rlu = []; ssum = 0.0; nguard = 0
        for g in self.Rgen:
            gi = int(g)
            w = float(td[gi]) if bool(am[gi]) else float(ad[gi])
            if abs(w) <= RETIRE_MIN_MW: continue
            x = max(-RETIRE_RAMP_FRAC * float(self.rd[gi]), min(RETIRE_RAMP_FRAC * float(self.ru[gi]), -w))
            if abs(x) <= RETIRE_MIN_MW: continue
            if x > 0.0 and float(gp[gi]) <= 1e-06 and (float(cst[gi]) > pt):
                nguard += 1
                continue                 # would turn a unit dearer than the setter ON -> whole bill up
            rlu.append((gi, float(x))); ssum += abs(float(x))
        if rlu and ssum >= RETIRE_MIN_SUM_MW and len(rlu) <= RETIRE_MAX_GENS:
            rl = rlu
        elif nguard and rl:
            # the retire was dropped, so the base list stands -- but the price guard still holds
            rl = [(_g, _x) for (_g, _x) in rl
                  if not (_x > 0.0 and float(gp[_g]) <= 1e-6 and float(cst[_g]) > pt)]
        if rl: parts["redispatch"] = rl
        if not no_soc and self.n_storage > 0:
            dt = float(getattr(obs, "delta_time", 5.0)) / 60.0
            SoC = np.asarray(obs.storage_charge, dtype=float)
            tgt = 0.5 * self.Emax
            dead = ECON_SOC_DEADBAND * np.maximum(self.Emax, 1e-9)
            p = (tgt - SoC) / max(dt, 1e-6)
            p = np.clip(p, -self.P_prod, self.P_absorb)
            sl = [(int(j), float(p[j])) for j in range(self.n_storage)
                  if abs(SoC[j] - tgt[j]) > dead[j] and abs(p[j]) > 1e-2]
            if sl: parts["set_storage"] = sl
        if not parts:
            return None
        try:
            parts = self._ramp_guard(obs, parts)
        except Exception:
            pass
        if not parts: return None
        try:
            act = gd.action_space(parts)
        except Exception:
            return None
        try:                                               # not the retire arithmetic -- count it, never time it
            res = obs.simulate(fin(act), time_step=1)
            if len(res) > 2 and res[2]: return None
            info = res[3] if len(res) > 3 else {}
            if info.get("exception"): return None
            st = res[0]; m = float(_cx(st.rho).max())   # (CA)
            _cl = SAFE_ECON_RHO if ceil is None else ceil
            if (not np.isfinite(m)) or m <= 0 or m >= _cl: return None
            if ceil is not None and m > float(np.asarray(obs.rho).max()) + ECON_RELAX_TOL: return None   # (dr1) never worsen under stress
            if ceil is None and ECON_SAFE_TOL >= 0.0 and (m > float(np.asarray(obs.rho).max()) + ECON_SAFE_TOL):
                return None                                  # (E4S) never worsen on the SAFE path either
            if self._bridge_lines(st) - self._bridge_lines(obs): return None
        except Exception:
            return None
        return act

    # ===================== (P5/P6) screen helpers =====================
    def _lodf_rank(self, O_base, O_n1, LPP, P0, k):
        """Top-k candidate config indices by the per-SWITCH LODF relevance of the cables each moves
        (max over moved cables of |LODF[l,k]*P0[k]| + tiny multi-cable tiebreak), interleaving base/N-1."""
        nl = self.nl
        def cfg_scores(rel):
            g = np.concatenate([rel, [-np.inf]])[self._scr_idx]
            smax = g.max(axis=1); g0 = np.where(np.isfinite(g), g, 0.0)
            return smax + 1e-3 * g0.sum(axis=1)
        def topk(score, kk):
            valid = np.where(np.isfinite(score) & (score > 0))[0]
            if len(valid) == 0: return []
            sel = valid if len(valid) <= kk else valid[np.argpartition(-score[valid], kk)[:kk]]
            return [int(i) for i in sel[np.argsort(-score[sel])]]
        idxb = idxn = []
        if len(O_base):
            cb = np.abs(LPP[O_base, :] * P0[None, :]); cb[~np.isfinite(cb)] = -np.inf
            idxb = topk(cfg_scores(cb.max(axis=0)), k)
        if len(O_n1):
            rn = np.full(nl, -np.inf)
            for (kc, l) in O_n1:
                if not np.isfinite(LPP[l, kc]): continue
                t = np.abs((LPP[l, :] + LPP[l, kc] * LPP[kc, :]) * P0); t[~np.isfinite(t)] = -np.inf
                rn = np.maximum(rn, t)
            idxn = topk(cfg_scores(rn), k)
        order = []; seen = set(); bi = iter(idxb); ni = iter(idxn)
        while True:
            adv = False
            for it in (bi, ni):
                nx = next(it, None)
                if nx is not None:
                    adv = True
                    if nx not in seen: seen.add(nx); order.append(nx)
            if not adv: break
        return order


    def _split_screen(self, O_base, O_n1, LPP, P0, Q0, Slim, on, Y0, dn, gp, lp, fc, base_bridges, legal, is_panic, s2=None):   # (S2) s2 = dict(extra, lim, per_area, n1) -> the S2 screen
        _cxon = (_CA_NOW[0][np.asarray(on, dtype=int)] if (CA_ON and len(_CA_NOW[0]) == self.nl) else 0.0)   # (CA)
        """(P6) DC BUS-SPLIT SENSITIVITY screen. LODF gives a coarse pool; the DC mini-prep then ranks the
        pool by the TRUE post-split worst loading via a rank-2 (+placeholder) Woodbury update of the cached
        base inverse Z = (B'_R)^-1 -- no predict() call. Predicted loading is anchored on the AC base P0."""
        nl = self.nl; ns = self.ns; nB = int(Y0.shape[0])
        cap = SWITCH_PREP_CAP * (PANIC_POOL_FACTOR if is_panic else 1)
        _w0 = (np.sqrt(P0 * P0 + Q0 * Q0))   # (P6-S0) cable weight = apparent flow
        pool = self._lodf_rank(O_base, O_n1, LPP, _w0, cap * SPLIT_POOL_MULT)
        if getattr(self, '_wp_gate', False):
            _seenS = set(int(self._scr_sub[i]) for i in pool)
            _addS = {}
            for _i in range(len(self._scr_sub)):
                _s0 = int(self._scr_sub[_i])
                if _s0 in _seenS: continue
                if s2 is not None and self._scr_ref[_i]: continue   # (S2) the reference config is not a split: WPG takes real configs; re-meshes come in s2["extra"]
                _l0 = _addS.setdefault(_s0, [])
                if len(_l0) < WPG_PER_SUB: _l0.append(_i)
            for _l0 in _addS.values(): pool.extend(_l0)
        try:
            _ovfE = np.asarray(getattr(self, '_ovf_now', np.zeros(nl, dtype=int)), dtype=int)
            _ksE = np.where(_ovfE >= NWTEP_COUNTER)[0]
            if len(_ksE):
                _subsE = set(int(self.or_sub[int(k)]) for k in _ksE) | set(int(self.ex_sub[int(k)]) for k in _ksE)
                _seenE = set(int(i) for i in pool); _addE = []; _perE = {}
                for _i in range(len(self._scr_sub)):
                    if int(self._scr_sub[_i]) in _subsE and int(_i) not in _seenE and not (s2 is not None and self._scr_ref[_i]):   # (S2) no reference configs
                        _perE.setdefault(int(self._scr_sub[_i]), []).append(int(_i)); _seenE.add(int(_i))
                _keysE = sorted(_perE); _ptrE = {k_: 0 for k_ in _keysE}   # (FIX1 F18) round-robin over the endpoint substations
                while len(_addE) < NWTEP_MAX:
                    _prog = False
                    for k_ in _keysE:
                        if _ptrE[k_] < len(_perE[k_]) and len(_addE) < NWTEP_MAX:
                            _addE.append(_perE[k_][_ptrE[k_]]); _ptrE[k_] += 1; _prog = True
                    if not _prog: break
                pool = list(pool) + _addE[:NWTEP_MAX]
                _Tn = self.__dict__.setdefault('_T', {}); _Tn['nwtep_added'] = _Tn.get('nwtep_added', 0) + len(_addE[:NWTEP_MAX]); _Tn['nwtep_steps'] = _Tn.get('nwtep_steps', 0) + 1
        except Exception:
            pass
        if s2 is not None:   # (S2) Newton grades the pool + the re-meshes on the state the exact check will see; the shortlist is PER AREA
            _tnw = time.time(); _livenw = np.asarray(fc.line_status, dtype=bool); _lim2 = s2['lim']; _n1s = s2.get('n1')
            _items = []
            for _c, _sb, _rm in ([(self._scr_cfg[i], int(self._scr_sub[i]), False) for i in pool] + [(_a, int(_s), True) for _a, _s in s2['extra']]):
                if _n1s is None:
                    _items.append((self._nwt_eb(_livenw, _c, _lim2), _c, _sb, _rm))
                else:   # (S2 NWT_N1) key = max(R1 base key, N-1 estimate / its bar)
                    _kb, _Pn, _Qn = self._nwt_eb(_livenw, _c, _lim2, want_pq=True)
                    _kn = self._s2_nwt_n1(_Pn, _Qn, _livenw, _n1s) if _Pn is not None else -1.0
                    _s2_cnt('nwt_n1_est'); _s2_cnt('nwt_n1_bind') if _kn > _kb else None   # (v2) print-only: the N-1 part set the key
                    _items.append((max(_kb, _kn), _c, _sb, _rm))
            _Tn = self.__dict__.setdefault('_T', {}); _Tn['nwt_calls'] = _Tn.get('nwt_calls', 0) + len(_items); _Tn['nwt_s'] = _Tn.get('nwt_s', 0.0) + (time.time() - _tnw)
            _items.sort(key=lambda t: t[0])   # stable: ties keep pool order
            _cur = np.asarray(fc.topo_vect); _per = {}; _psub = {}; _out = []
            _nA = len(set(int(x) for x in self.sub_area if int(x) >= 0)); _capA = int(s2['per_area']); _capS = int(S2_SUBCAP)
            for _k, _c, _sb, _rm in _items:
                if len(_per) >= _nA and all(v >= _capA for v in _per.values()): break
                _a = int(self.sub_area[_sb])
                if _per.get(_a, 0) >= _capA: continue
                if _capS > 0 and _psub.get(_sb, 0) >= _capS: _s2_cnt('subcap_skip'); continue   # (S2 SUBCAP) substation at its cap: keep walking down the ranking
                if (not _rm) and (not legal(_c)): continue
                _tvc = np.asarray(_c._set_topo_vect)
                if not np.any((_tvc != 0) & (_cur > 0) & (_tvc != _cur)): continue   # changes nothing on the graded state
                if self._new_bridges_of_set_bus(_c, fc.topo_vect, fc.line_status, base_bridges): continue
                _per[_a] = _per.get(_a, 0) + 1; _psub[_sb] = _psub.get(_sb, 0) + 1
                _out.append(dict(key=float(_k), act=_c, sub=_sb, area=_a, remesh=_rm))
            _s2_cnt('pool', len(_items)); _s2_cnt('short', len(_out)); _s2_cnt('short_remesh', sum(1 for _o in _out if _o['remesh']))
            return _out
        if not pool:
            return []

        def _filtered(order):                       # legality + no-new-bridge fallback path
            out = []
            for i in order:
                c = self._scr_cfg[i]
                if not legal(c): continue
                if self._new_bridges_of_set_bus(c, fc.topo_vect, fc.line_status, base_bridges): continue
                out.append(c)
                if len(out) >= cap: break
            return out

        # ---- DC base, once per step ----
        try:
            Bp0 = self._gbbp(Y0)[2]
            R = np.arange(1, nB)                     # drop slack = bus 0
            Zr = np.linalg.inv(Bp0[np.ix_(R, R)])
            Z = np.zeros((nB, nB)); Z[np.ix_(R, R)] = Zr
            base_cond = float(np.abs(Bp0[np.ix_(R, R)]).sum(0).max() * np.abs(Zr).sum(0).max())  # cheap 1-norm cond estimate
        except Exception:
            return _filtered(pool)                   # DC base unavailable -> keep LODF order
        if (not np.isfinite(base_cond)) or base_cond > SPLIT_COND_MAX:
            return _filtered(pool)                   # (P6 guard) grid fragmented / ill-conditioned -> trust LODF, not DC
        llb = self._ll(dn["oc"]); orb = llb[:, 0].astype(int); exb = llb[:, 1].astype(int)
        on_a = np.asarray(on, dtype=int)
        bln = np.zeros(nl)
        for k in on_a: bln[int(k)] = -Bp0[orb[int(k)], exb[int(k)]]
        p = np.zeros(nB)
        np.add.at(p, orb[on_a], P0[on_a]); np.add.at(p, exb[on_a], -P0[on_a])
        th_base = Z @ p
        orb_on = orb[on_a]; exb_on = exb[on_a]
        P0_on = P0[on_a]; Q0_on = Q0[on_a]; Slim_on = Slim[on_a]; bln_on = bln[on_a]
        # (P6-CAL) grid2op rho is a CURRENT ratio (voltage-dependent): sqrt(P^2+Q^2)/thermal_limit is off by a
        # per-line LEVEL factor (line 136 measured: 0.205 vs true rho 0.835). That is WHY `Slim` is built in
        # decide() as S0/rho0 and NOT from env.get_thermal_limit(). Slim_on is therefore ALREADY the true-rho
        # denominator: ba (below) == max(fc.rho[on]) at zero topology change, and the Woodbury only has to get
        # the DELTA right. A re-anchoring block used to sit here; it recomputed S0/rho0 and wrote back exactly
        # what Slim_on already held (measured 0 of 6445 entries changed over 35 calls, max|d| 0.0), so it was
        # DELETED (Z1, review finding 12). IF the `Slim =` line in decide() is ever moved to thermal limits or
        # loses its 1e6 down-line placeholder, ba, the BA_SECURE=1 count and the PREP_ADAPTIVE early stop stop
        # being in true-rho units -- re-anchor THERE, in decide(), not here.
        Yrow = np.abs(Y0).sum(axis=1)               # base bus occupancy (empty bus-2 node => can DC-split cheaply)
        pos_in_on = -np.ones(nl, dtype=int); pos_in_on[on_a] = np.arange(len(on_a))
        f_base_on = bln_on * (th_base[orb_on] - th_base[exb_on])         # DC base flow on `on` (~ P0_on)
        _pair = {}
        for _k in on_a:
            _k = int(_k); _key = (min(orb[_k], exb[_k]), max(orb[_k], exb[_k])); _pair[_key] = _pair.get(_key, 0) + 1
        tainted = np.zeros(nl, dtype=bool)                              # parallel corridor: bln is the COMBINED susceptance -> DC unreliable
        for _k in on_a:
            _k = int(_k); _key = (min(orb[_k], exb[_k]), max(orb[_k], exb[_k]))
            if _pair[_key] > 1: tainted[_k] = True

        reliable = []                                # (ba, i) with a TRUSTED DC estimate
        fallback = []                                # i, kept in LODF pool order (DC not trusted)
        dcstore = {}                                 # i -> DC ba, recorded only where DC was actually computed (for the self-check)
        for i in pool:
            sub = int(self._scr_sub[i]); s = sub; sp = sub + ns
            if sp >= nB or Yrow[sp] > 1e-9:          # base substation already split / no empty bus-2 slot
                fallback.append(i); continue
            mv = self._scr_idx[i]; mv = mv[mv >= 0]
            g = np.zeros(nB); beta = 0.0; ok = True
            for kk in mv:
                kk = int(kk); bk = bln[kk]
                if bk == 0.0: continue
                if tainted[kk]: ok = False; break          # parallel corridor -> DC unreliable
                far = exb[kk] if orb[kk] == s else (orb[kk] if exb[kk] == s else -1)
                if far < 0: ok = False; break
                g[s] += bk; g[int(far)] -= bk; beta += bk
            if (not ok) or beta == 0.0:
                fallback.append(i); continue
            u = np.zeros(nB); u[sp] = 1.0; u[s] = -1.0
            enew = np.zeros(nB); enew[sp] = 1.0
            U = np.stack([u, g, enew], axis=1)
            C = np.array([[beta, 1.0, 0.0], [1.0, 0.0, 0.0], [0.0, 0.0, -1.0]])
            try:
                ZU = Z @ U
                S = np.linalg.inv(C) + U.T @ ZU
                condS = np.linalg.cond(S)
                if (not np.isfinite(condS)) or condS > SPLIT_COND_MAX:   # (P6 guard) near-islanding split -> Woodbury unreliable
                    fallback.append(i); continue
                P_B = float(gp[self._scr_gen2[i]].sum() - lp[self._scr_load2[i]].sum())   # moved net injection (gens-loads)
                dp = np.zeros(nB); dp[sp] += P_B; dp[s] -= P_B
                q = th_base + Z @ dp
                th_new = q - ZU @ np.linalg.solve(S, U.T @ q)
                fn_or = th_new[orb_on].copy(); fn_ex = th_new[exb_on].copy()
                for kk in mv:                                            # moved lines reconnect at the new bus s'
                    kk = int(kk); pidx = pos_in_on[kk]
                    if pidx < 0: continue
                    if orb[kk] == s: fn_or[pidx] = th_new[sp]
                    elif exb[kk] == s: fn_ex[pidx] = th_new[sp]
                Pf = P0_on + (bln_on * (fn_or - fn_ex) - f_base_on)      # AC base + DC topology delta (moved lines at s')
                ba = float(np.max(np.sqrt(Pf * Pf + Q0_on * Q0_on) / Slim_on + _cxon))   # (CA)
            except Exception:
                fallback.append(i); continue
            dcstore[i] = ba
            if (not np.isfinite(ba)) or ba > SPLIT_BA_CAP:               # (P6 guard) blow-up / absurd -> don't trust the number
                fallback.append(i); continue
            reliable.append((ba, i))

        _tnw = time.time(); _livenw = np.asarray(fc.line_status, dtype=bool)
        reliable = [(self._nwt_eb(_livenw, self._scr_cfg[i]), i) for i in pool]
        fallback = []
        _Tn = self.__dict__.setdefault('_T', {}); _Tn['nwt_calls'] = _Tn.get('nwt_calls', 0) + len(pool); _Tn['nwt_s'] = _Tn.get('nwt_s', 0.0) + (time.time() - _tnw)
        reliable.sort(key=lambda t: t[0])            # DC-trusted candidates first, lowest predicted loading first
        order = [i for _, i in reliable] + fallback  # untrusted ones keep their LODF pool order
        _ba = {i: ba for ba, i in reliable}          # (ADAPT) DC-predicted worst loading per config
        shortlist = []; _nsec = 0
        for i in order:
            c = self._scr_cfg[i]
            if not legal(c): continue
            _tvc = np.asarray(c._set_topo_vect); _cur = np.asarray(fc.topo_vect)
            if not np.any((_tvc != 0) & (_cur > 0) & (_tvc != _cur)): continue
            if self._new_bridges_of_set_bus(c, fc.topo_vect, fc.line_status, base_bridges): continue
            shortlist.append(c)
            if _ba.get(i, 9.9) < (min(BA_SECURE, BASE_LIMIT) if FIX1_ON else BA_SECURE): _nsec += 1        # (FIX1 F12) the 0.99 clear bar   # (ADAPT) count DC-secure candidates kept
            if len(shortlist) >= cap: break
            if (not is_panic and len(O_base) > 0 and (len(O_n1) == 0)) and _nsec >= PREP_FLOOR and (len(shortlist) >= PREP_FLOOR):   # (FIX1 F12) non-panic, base-only steps
                break                                          # (ADAPT) enough easy wins -> stop (never in panic)
        return shortlist

    # ===================== (v4) multi-area aggressive reconnection =====================


    # ===================== decision engine =====================
    def _T_mark(self, nm):   # (TIME) close the open stage bucket, open `nm`
        _T = self.__dict__.setdefault('_T', {}); _tm = getattr(self, '_tm', None); _now = time.time()
        if _tm is not None: _T[_tm[1]] = _T.get(_tm[1], 0.0) + (_now - _tm[0])
        self._tm = [_now, nm]
    def _T_close(self):   # (TIME)
        _T = self.__dict__.setdefault('_T', {}); _tm = getattr(self, '_tm', None)
        if _tm is not None: _T[_tm[1]] = _T.get(_tm[1], 0.0) + (time.time() - _tm[0])
        self._tm = None
    def _nwt_init(self):   # (NWT)
        gd = self.gd
        self._nls = len(self._nwt_grid.get_lines())   # (NOENV) the forecast grid being graded (same structure); None -> 9.99 as before
        LOR = np.asarray(gd.line_or_pos_topo_vect); LEX = np.asarray(gd.line_ex_pos_topo_vect)
        GEN = np.asarray(gd.gen_pos_topo_vect); LOD = np.asarray(gd.load_pos_topo_vect)
        STO = np.asarray(gd.storage_pos_topo_vect) if hasattr(gd, 'storage_pos_topo_vect') else np.array([], dtype=int)
        self._nwt_subof = np.concatenate([np.full(n, i) for i, n in enumerate(gd.sub_info)])
        p2e = {}
        for i, p in enumerate(LOR): p2e[int(p)] = ('lor', i)
        for i, p in enumerate(LEX): p2e[int(p)] = ('lex', i)
        for i, p in enumerate(GEN): p2e[int(p)] = ('gen', i)
        for i, p in enumerate(LOD): p2e[int(p)] = ('load', i)
        for i, p in enumerate(STO): p2e[int(p)] = ('sto', i)
        self._nwt_p2e = p2e
        self._nwt_ready = True
    def _nwt_eb(self, live, cfg, lim=None, want_pq=False):   # (NWT) warm capped-Newton post-split worst loading; 9.99 on non-convergence   # (S2) lim -> relative to each line's own threshold; want_pq -> (key, P, Q)
        try:
            if not getattr(self, '_nwt_ready', False): self._nwt_init()
            grid = getattr(self, '_nwt_grid', None)
            if grid is None: return (9.99, None, None) if want_pq else 9.99
            V0 = np.array(grid.get_V())
            g2 = grid.copy()
            tv = np.asarray(cfg._set_topo_vect)
            for p in np.where(tv != 0)[0]:
                b = int(tv[p]); sub = int(self._nwt_subof[p])
                gbus = sub if b == 1 else sub + self.ns
                if b == 2:
                    try: g2.reactivate_bus(gbus)
                    except Exception: pass
                kind, i = self._nwt_p2e[int(p)]
                if kind == 'lor':
                    if i < self._nls: g2.change_bus1_powerline(i, gbus)
                    else: g2.change_bus1_trafo(i - self._nls, gbus)
                elif kind == 'lex':
                    if i < self._nls: g2.change_bus2_powerline(i, gbus)
                    else: g2.change_bus2_trafo(i - self._nls, gbus)
                elif kind == 'gen': g2.change_bus_gen(i, gbus)
                elif kind == 'load': g2.change_bus_load(i, gbus)
                elif kind == 'sto': g2.change_bus_storage(i, gbus)
            Vi = V0.copy(); Vi[np.abs(Vi) < 1e-6] = 1.0 + 0.0j
            Vh = g2.ac_pf(Vi, NWT_ITERS, NWT_TOL)
            if len(Vh) == 0: return (9.99, None, None) if want_pq else 9.99
            res = np.concatenate([np.abs(np.array([l.res_a1_ka for l in g2.get_lines()])) * 1000.0,
                                  np.abs(np.array([t.res_a1_ka for t in g2.get_trafos()])) * 1000.0])
            rvec = res / np.maximum(self._nwt_rate, 1e-6)
            rvec = _cx(rvec)   # (CA)
            if lim is not None: rvec = rvec / lim   # (S2) R1: (Newton loading + correction) / the line's own threshold
            m = np.asarray(live, dtype=bool) & (self._nwt_rate > 0)
            _v = float(np.max(rvec[m])) if m.any() else 9.99
            if want_pq:   # (S2 NWT_N1) origin-side P, Q of every line of the Newton state (grid2op p_or / q_or order)
                _P = np.concatenate([np.array([l.res_p1_mw for l in g2.get_lines()]), np.array([t.res_p1_mw for t in g2.get_trafos()])])
                _Q = np.concatenate([np.array([l.res_q1_mvar for l in g2.get_lines()]), np.array([t.res_q1_mvar for t in g2.get_trafos()])])
                return _v, _P, _Q
            return _v
        except Exception:
            return (9.99, None, None) if want_pq else 9.99
    # ===================== (S2) DECISION PIPELINE, draft 7 (decision_pipeline_S2_draft7.html) =====================
    # Phase A (FCFIX, attack tracker, correction, maintenance view, base forecast) and Phase E (probe rider, correction
    # reference, maintenance strip, fin) stay the source's own code in decide() / act().  decide() hands over here twice:
    # at the security check (_s2_begin -> _s2_phase_b) and after the do-nothing linearisation (_s2_phase_c).
    # X = the step context: obs (maintenance view), fc (do-nothing forecast; = obs if the forecast failed), fin, base_sim,
    # lim (each line's own threshold: OL if its counter runs, else NL), ovf (counters), base_bridges, dn (do-nothing's record).
    # A record = one exact check: ok (False = failed outright), live, r (corrected loading), rmax (worst over live lines),
    # rrel (worst loading / own threshold), bclear, en (worstN1_exact), n1raw, clear, sc (score), key (sort key).
    def _s2_credible(self, obs, st):
        """credible lines ON THE CHECKED STATE st: the most-loaded (corrected) live attackable line of each area + every
        live line whose maintenance starts within MAINT_HORIZON steps (and within S2_MNT3_H when S2_MNT3 is on)."""
        ls = np.asarray(st.line_status, dtype=bool); r = _cx(st.rho); cred = []
        for area in self.attack_by_area:
            live = [int(k) for k in area if ls[k]]
            if live: cred.append(int(max(live, key=lambda k: r[k])))
        tnm = np.asarray(obs.time_next_maintenance, dtype=int)
        hz = (MAINT_HORIZON)
        for k in np.where(ls & (tnm > 0) & (tnm <= hz))[0]:
            if int(k) not in cred: cred.append(int(k))
        if not st is getattr(self, '_leth_dn_st', None):   # (LETHAL) a split substation of the map -> its lethal lines are credible in THIS state
            _ids = getattr(self, '_leth_ids', None)
            if _ids is None:
                _n2i = {str(n): i for i, n in enumerate(type(st).name_line)}
                _ids = {int(sb): [int(_n2i[n]) for n in ns if n in _n2i] for sb, ns in S2_LETHAL_MAP.items()}
                self._leth_ids = _ids
            _tv = np.asarray(st.topo_vect)
            for sb, ks in _ids.items():
                if np.any(_tv[self.pos2sub == sb] == 2) and (not (getattr(self, '_leth_dn_st', None) is not None and np.any(np.asarray(self._leth_dn_st.topo_vect)[self.pos2sub == sb] == 2))):   # (LETHAL) NEWSPLIT: a substation already split in do-nothing is skipped (new splits only)
                    for k in ks:
                        if ls[k] and k not in cred:
                            cred.append(int(k)); _s2_cnt('lethal_cred')
                            if S2_LETHAL_BAR > 0.0: self._n1lim[int(k)] = float(S2_LETHAL_BAR)   # (LETHAL) per-line post-outage bar (own-threshold units, as MNT3 / KLB)
        return cred

    def _s2_fail(self, why=None):   # a candidate that FAILED OUTRIGHT: it never clears and is never "best"
        if why: _s2_cnt('fail_' + why)
        return dict(ok=False, why=why, st=None, r=None, live=None, eb=9.99, en=9.99, n1raw=9.99, n1isl=True, rmax=9.99, rrel=9.99,
                    bclear=False, clear=False, sc=float('inf'), key=(float('inf'),), cred=[])

    def _s2_state(self, X, st):
        """the part of the exact check read from one forecast state: every live line's corrected loading vs its own threshold"""
        live = np.asarray(st.line_status, dtype=bool); r = _cx(st.rho); rl = r[live]; L = X['lim'][live]
        ok = rl.size > 0 and bool(np.all(np.isfinite(rl)))
        if not ok:
            rec = self._s2_fail('nonfinite'); rec.update(st=st, r=r, live=live); return rec
        _s = BASE_LIMIT / L
        lev = float((rl * _s).max())   # the source's _b_eff on the live lines of THIS state
        v = float((np.clip(rl - L, 0.0, None) * _s).sum())
        eb = (BASE_LIMIT + v) if v > 0.0 else lev
        return dict(ok=True, st=st, r=r, live=live, eb=eb, en=None, n1raw=None, n1isl=False, rmax=float(rl.max()),
                    rrel=float((rl / L).max()), bclear=bool(np.all(rl < L)), clear=False, sc=None, key=None, cred=[])

    def _s2_n1(self, X, rec):
        """exact N-1 of the credible lines of rec's OWN state (worstN1_exact: one contingency at a time, do_copy=True),
        then clear + score.  The restore stages call it lazily, in their choice order: their choice never reads N-1.
        Per-step cache keyed by the state: a state's N-1 is computed once, whatever record asks for it."""
        if (not rec['ok']) or rec['en'] is not None: return rec
        _nc = X['n1c'].get(id(rec['st']))
        if _nc is None:
            X['nn1'] += 1; _s2_cnt('n1')
            _cred = self._s2_credible(X['obs'], rec['st'])
            _en = float(self.worstN1_exact(rec['st'], _cred))
            _nc = (_cred, _en, int(getattr(self, '_n1_ndiv', 0)) > 0, float(getattr(self, '_n1_raw', _en)), ((dict(getattr(self, '_n1_stash', {})))))   # (LP) + the stash
            X['n1c'][id(rec['st'])] = _nc
        rec['cred'], rec['en'], rec['n1isl'], rec['n1raw'] = list(_nc[0]), _nc[1], _nc[2], _nc[3]
        rec['n1s'] = _nc[4]   # (LP) exact post-contingency flows of this state (None unless S2_LP)
        rec['clear'] = bool(rec['bclear']) and rec['en'] < N1_LIMIT
        rec['sc'] = self._s2_m6(X, rec); rec['key'] = (rec['sc'], rec['rrel'], rec['n1raw'])
        return rec

    def _s2_m6(self, X, rec):
        """(M6) expected trip-equivalents (lower is better): per live line, with its corrected loading rho, its counter
        c = clip(counter - S2_M6_SHIFT, 0, 2) and s = S2_M6_SIGMA: P1 = Phi((rho-1)/s), P2 = Phi((rho-2)/s), E1 = s (x Phi(x) + phi(x)),
        x = (rho-1)/s, risk = P2 + (1-P2) min(1, W[c] P1 + M[c] E1); plus the N-1 term on the RAW worst N-1 loading."""
        s = float(S2_M6_SIGMA); live = rec['live']; rho = rec['r'][live]
        c = np.clip(X['ovf'][live] - int(S2_M6_SHIFT), 0, 2)   # (v2) v1: np.minimum(counter, 2)
        W = np.asarray(S2_M6_W, dtype=float)[c]; M = np.asarray(S2_M6_M, dtype=float)[c]
        x = (rho - 1.0) / s
        P1 = _s2_Phi(x); P2 = _s2_Phi((rho - 2.0) / s); E1 = s * (x * P1 + _s2_phi(x))
        lr = P2 + (1.0 - P2) * np.minimum(1.0, W * P1 + M * E1)
        n = float(rec['n1raw'])
        tn = (S2_M6_WN1 / 3.0) * (3.0 if rec['n1isl'] else float(_s2_Phi((n - 2.0) / 0.05) + 0.15 * _s2_Phi((n - 1.0) / 0.05)))
        return float(lr.sum()) + tn

    @staticmethod
    def _s2_akey(a):   # the content of an action (what grid2op would apply), for the per-step exact-check cache
        return b'|'.join(np.asarray(getattr(a, nm)).tobytes() for nm in
                         ('_set_topo_vect', '_set_line_status', '_change_bus_vect', '_switch_line_status', '_redispatch', '_storage_power', '_curtail')
                         if getattr(a, nm, None) is not None)

    def _s2_ev(self, X, act, n1=True):
        """(S2) THE EXACT CHECK of one candidate: simulate fin(act) one step (fin attaches the prefix once it is chosen, and
        the source's strips), corrected per-line loading vs own threshold, exact N-1 of the credible lines of that state.
        Fails outright if grid2op refuses it, if the simulation trips a line do-nothing keeps, or if it creates a new radial line.
        Per-step cache: the same final action is never simulated twice in a step (records are returned as copies)."""
        try:
            fa = X['fin'](act)
        except _GPTPhaseAConflict:
            return self._s2_fail('conflict')
        _ak = self._s2_akey(fa)
        c = X['evc'].get(_ak)
        if c is None:
            c = self._s2_sim(X, fa); X['evc'][_ak] = c
        else:
            _s2_cnt('ev_cached')
        rec = dict(c)
        return self._s2_n1(X, rec) if (n1 and rec['ok']) else rec

    def _s2_sim(self, X, fa):
        """the simulation half of the exact check (no N-1)"""
        X['nsim'] += 1; _s2_cnt('sim')
        try:
            res = X['obs'].simulate(fa, time_step=1)
            if len(res) > 2 and res[2]: return self._s2_fail('done')
            inf = res[3] if len(res) > 3 and isinstance(res[3], dict) else {}
            if inf.get("is_illegal") or inf.get("is_ambiguous") or inf.get("failed_redispatching") or inf.get("exception"): return self._s2_fail('refused')
            st = res[0]; fc = X['fc']
            if fc is not X['obs']:   # (FIX1 F2, FIX1b gate) a line live in the do-nothing forecast that the simulation trips
                off = np.where(np.asarray(fc.line_status, dtype=bool) & ~np.asarray(st.line_status, dtype=bool))[0]
                if len(off) and np.any(np.asarray(fa._set_line_status)[off] != -1): return self._s2_fail('trip')
            rec = self._s2_state(X, st)
            if (not rec['ok']) or rec['eb'] <= 0: return self._s2_fail('nonfinite')
            if self._bridge_lines(st) - X['base_bridges']: return self._s2_fail('radial')   # a new radial line
            return rec
        except Exception:
            _s2_cnt('ev_exc')
            if S2_DIAG.get('ev_exc', 0) <= 3: print('S2 EV-ERROR step=%d %s' % (X['step'], _s2_tb.format_exc()[-1500:]), flush=True)
            return self._s2_fail('exc')

    def _s2_legal(self, X, act):
        """prefix-compatible and inside grid2op's area budget and cooldowns (_gpt_a_compatible checks the budget only
        when a prefix exists, so without one _gpt_a_budget is asked directly)"""
        try:
            if not _gpt_a_compatible(self, X['obs'], act): return False
            if getattr(self, '_gpt_a_prefix', None) is not None: return True
            return bool(_gpt_a_budget(self, X['obs'], act))
        except Exception:
            return False

    def _s2_out(self, X, act, src, rec):
        """commit fin(act) (prefix + candidate + the source's strips) and write the STEPLOG line"""
        a = X['fin'](act); _s2_cnt('out_' + src)
        if _s2_steplog():
            _dn = X['dn']
            print('S2STEP step=%d src=%s prefix=%d nsim=%d nn1=%d before=%.4f after=%.4f dn_n1=%.3f n1=%.3f' % (
                X['step'], src, int(getattr(self, '_gpt_a_prefix', None) is not None), X['nsim'], X['nn1'],
                float(_dn['rmax']), float(rec['rmax']), float(_dn['en'] if _dn['en'] is not None else -1.0),
                float(rec['en'] if rec.get('en') is not None else -1.0)), flush=True)
        return a, dict(secure=False, sub=-1, rl=[], cl=[], sl=[], base=X['dn']['rmax'], n1=X['dn']['en'],
                       pb=rec['rmax'], pn=rec.get('en'), status=src)

    def _s2_begin(self, obs, fc, fin, base_sim):
        """the step context + do-nothing's exact check, read from the base forecast fc (fin(do_nothing) IS that forecast)"""
        ovf = np.asarray(obs.timestep_overflow, dtype=int)
        X = dict(obs=obs, fc=fc, fin=fin, base_sim=base_sim, ovf=ovf, lim=np.where(ovf > 0, OL, NL),
                 step=int(getattr(obs, 'current_step', -1)), nsim=0, nn1=0, keep=[], evc={}, n1c={})
        self._n1lim = {}   # (FIX1 F9) rebuilt every step; KLB is off, so the S2_MNT3 entries below are the only ones
        self._wp_gate = bool(np.any(ovf > 0))   # (S2) the WPG extra configs whenever a counter runs, in every month
        X['base_bridges'] = self._bridge_lines(fc)
        self._leth_dn_st = fc   # (LETHAL) the do-nothing state of this step (S2_LETHAL_CAND_ONLY skips it)
        X['dn'] = self._s2_n1(X, self._s2_state(X, fc))
        X['dn']['act'] = self.do_nothing
        _s2_cnt('steps')
        if X['step'] == 0: self._mntd_fires = {}
        self._s2_mntd_prepare(X)   # (MNTD) forecast certain outage at Phase A
        return X

    def _s2_combo_list(self, X):
        """every area-legal combination of <= 1 reconnect and <= 1 re-mesh in each area (_gpt_restore_options), budget-
        checked, in enumeration order, NOT simulated yet.  A re-mesh that changes nothing is not a restoration."""
        obs = X['obs']; tv = np.asarray(obs.topo_vect); out = []
        for action, ls, ss in _gpt_restore_options(self, obs, None, False):
            if not _gpt_a_budget(self, obs, action): continue
            if ss:
                tva = np.asarray(action._set_topo_vect); noop = False
                for s in ss:
                    m = self.pos2sub == int(s)
                    if not np.any((tva[m] != 0) & (tv[m] > 0) & (tva[m] != tv[m])): noop = True; break
                if noop: continue
            out.append(dict(act=action, ls=[int(k) for k in ls], ss=[int(x) for x in ss], nrest=len(ls) + len(ss)))
        _s2_cnt('combos', len(out))
        return out

    def _s2_combo_sim(self, X, c):
        """the simulation half of a combination's exact check (N-1 lazily, later).  A reconnect that is not in service after
        the simulation did not happen (the rule of the source's _gpt_forecast): such a combination is dropped (None)."""
        rec = self._s2_ev(X, c['act'], n1=False)
        if not rec['ok']:
            if c['ls']: _s2_cnt('fail_reco_' + str(rec.get('why')))   # (v2) print-only: why restorations with a reconnect fail
            return None
        if any(not bool(rec['live'][k]) for k in c['ls']): _s2_cnt('fail_noreco'); return None
        rec.update(act=c['act'], ls=c['ls'], ss=c['ss'], nrest=c['nrest'], subs=frozenset(c['ss']), nact=c['nrest'], src='RESTORE')
        return rec

    def _s2_combos(self, X):   # every combination simulated (Phase C: RESTORE-CLEAR and the prefix need all of them)
        return [r for r in (self._s2_combo_sim(X, c) for c in self._s2_combo_list(X)) if r is not None]

    def _s2_phase_b(self, X):
        """Phase B (secure): RESTORE.  Every combination must still clear (N-1 included).  do-nothing's corrected worst
        loading > RESTORE_SWITCH: the lowest corrected worst loading (ties: more restorations); otherwise, among those not
        above do-nothing's worst, the most reconnects + re-meshes (ties: the lower worst).  None -> do nothing.
        Cheap and identical: N-1 runs only in the rule's order until the first clearing one; under the 'most restorations'
        rule the combinations are also simulated tier by tier (most restorations first): a lower tier is simulated only if
        no combination of the tiers above qualified, which is exactly when the full sort would reach it."""
        self._T_mark('restore_b'); _s2_cnt('secure')
        dnr = X['dn']; CL = self._s2_combo_list(X)
        if dnr['rmax'] > RESTORE_SWITCH:
            tiers = [CL]
            keyf = lambda c: (c['rmax'], -c['nrest'])
            okf = lambda c: c['bclear'] and ((not S2_RESTORE_NORAISE) or c['rmax'] <= dnr['rmax'])   # (NORAISE)
        else:
            tiers = [[c for c in CL if c['nrest'] == n] for n in sorted(set(c['nrest'] for c in CL), reverse=True)]
            keyf = lambda c: c['rmax']
            okf = lambda c: c['bclear'] and c['rmax'] <= dnr['rmax']
        for tier in tiers:
            recs = [r for r in (self._s2_combo_sim(X, c) for c in tier) if r is not None and okf(r)]
            for c in sorted(recs, key=keyf):   # stable: ties keep the enumeration order
                if self._s2_n1(X, c)['clear']:
                    return self._s2_restore_econ(X, c)
        return self._s2_econ(X)

    def _s2_econ(self, X):
        """(ECON) Phase B when RESTORE found nothing.  The source's secure economic step, called as the source's secure branch
        called it with USE_SAFE_ECON on: self._rg_fc = the do-nothing forecast (RAMPGUARD's natural-change term), then
        _safe_economic(obs, fin) with its own guards (RAMPGUARD scaling, U1 price guard, corrected worst loading < SAFE_ECON_RHO,
        no new bridge; BAND_RELAX and E4 stay off).  Its action must then pass THE S2 EXACT CHECK (_s2_ev: every live line inside
        its own threshold NL / OL with the correction, exact N-1 of the credible lines < N1, the fail-outright rules).
        Clear -> commit it; otherwise do nothing."""
        self._T_mark('econ'); _s2_cnt('econ_call')
        if bool(np.any(X['ovf'] > 0)): _s2_cnt('econ_call_ovf')   # print-only: a counter runs (the source's secure branch never saw one)
        self._rg_fc = X['fc']   # (RAMPGUARD) as at the source's secure call sites
        ec = self._safe_economic(X['obs'], X['fin'])
        if ec is None:
            _s2_cnt('econ_none'); return self.do_nothing, dict(secure=True)
        rec = self._s2_ev(X, ec)
        if rec['ok'] and rec['clear']:
            return self._s2_out(X, ec, 'ECON', rec)
        _s2_cnt('econ_fail_' + (('sim_' + str(rec.get('why'))) if not rec['ok'] else ('bar' if not rec['bclear'] else 'n1')))
        return self.do_nothing, dict(secure=True)

    def _s2_restore_econ(self, X, c):
        """(ECON) Phase B when RESTORE chose R = c['act'] (c = its cleared exact-check record).  The same secure economic step on
        R's topology: self._rg_fc = R's exact-check state, and every simulation _safe_economic makes is fin(R + its action).
        R + E must pass _s2_legal (the economic part uses no area budget) and THE S2 EXACT CHECK (_s2_ev).  Clear -> commit R + E;
        otherwise commit R alone, exactly as the source does."""
        self._T_mark('econ'); _s2_cnt('restore_econ_call')
        if bool(np.any(X['ovf'] > 0)): _s2_cnt('restore_econ_call_ovf')   # print-only
        R = c['act']; _fin = X['fin']
        self._rg_fc = c['st']   # (RAMPGUARD) the base forecast is R's exact-check state
        ec = self._safe_economic(X['obs'], lambda a: _fin(R + a))
        if ec is None:
            _s2_cnt('restore_econ_none'); return self._s2_out(X, R, 'RESTORE', c)
        RE = R + ec
        if not self._s2_legal(X, RE):
            _s2_cnt('restore_econ_fail_legal'); return self._s2_out(X, R, 'RESTORE', c)
        rec = self._s2_ev(X, RE)
        if rec['ok'] and rec['clear']:
            _s2_cnt('restore_econ_commit'); return self._s2_out(X, RE, 'RESTORE+ECON', rec)
        _s2_cnt('restore_econ_fail_' + (('sim_' + str(rec.get('why'))) if not rec['ok'] else ('bar' if not rec['bclear'] else 'n1')))
        return self._s2_out(X, R, 'RESTORE', c)

    def _s2_prep(self, X, prep, act):
        """one sensitivity build (the source's prep) of the topology fin(act): exactly the action it stands for, prefix included"""
        try:
            pc = prep(X['fin'](act))
        except Exception:
            pc = None
        _s2_cnt('topo_prep' if pc is not None else 'topo_prep_fail')
        return pc

    def _s2_nwt_n1(self, P, Q, live, n1s):
        """(S2 NWT_N1) N-1 estimate of a Newton state: do-nothing's AC LODF applied to its per-line P, Q for every credible
        contingency k; loading = sqrt(P'^2 + Q'^2) / Slim + correction, over the lines l != k; / the contingency's bar
        (N1, or NL for an S2_MNT3 certain outage).  A radial / NaN column counts as 9.99, as the exact check would."""
        L = n1s['L']; SL = n1s['slim']; corr = n1s['corr']; worst = 0.0
        for k in n1s['cred']:
            div = n1s['div'].get(int(k), N1_LIMIT)
            if n1s['rad'][k] or not np.all(np.isfinite(L["PP"][:, k])):
                return 9.99 / div
            Pk = P + L["PP"][:, k] * P[k] + L["PQ"][:, k] * Q[k]
            Qk = Q + L["QP"][:, k] * P[k] + L["QQ"][:, k] * Q[k]
            m = live.copy(); m[k] = False
            if not m.any(): continue
            w = float(np.max(np.sqrt(Pk[m] ** 2 + Qk[m] ** 2) / SL[m] + corr[m])) / div
            if not np.isfinite(w): return 9.99 / div
            worst = max(worst, w)
        return worst

    def _s2_reco(self, k, base=None):
        """(S2 v2) the reconnection of line k.  With S2_RECO_BUS1 each end is set to bus 1 unless `base` (the action it joins)
        already sets that end: set_line_status alone makes grid2op put an end back on the bus it left, and when that was bus 2
        of a substation re-meshed since, the line comes back alone on an empty bus (dangling, no flow; the exact check fails it
        as a new radial line, so the line could never be restored).  Measured: the reconnect-with-bus uses no substation budget
        (get_topological_impact: subs []) and stays legal while the substation cools down."""
        d = {"set_line_status": [(int(k), 1)]}
        tv = None if base is None else np.asarray(base._set_topo_vect)
        sb = {}
        if tv is None or tv[self.or_pos[int(k)]] == 0: sb["lines_or_id"] = [(int(k), 1)]
        if tv is None or tv[self.ex_pos[int(k)]] == 0: sb["lines_ex_id"] = [(int(k), 1)]
        if sb: d["set_bus"] = sb
        return self.gd.action_space(d)

    def _s2_disc_radial(self, X, T, k):
        """would switching line k off on topology T leave a NEW radial line?  (the exact check's own fail rule, applied before
        a kept slot is spent on a disconnection that cannot pass it)"""
        oc = T['pc']['oc']; ls = np.asarray(oc.line_status, dtype=bool).copy(); ls[int(k)] = False; tv = np.asarray(oc.topo_vect)
        bor = self.or_sub + (tv[self.or_pos] - 1) * self.ns; bex = self.ex_sub + (tv[self.ex_pos] - 1) * self.ns
        return bool(self._bridges_from_buses(ls, bor, bex) - X['base_bridges'])

    def _s2_line_est(self, X, ti, T, corr):
        """(S2) the line actions of one topology T, estimated from its sensitivity build T['pc']:
          disconnection of a live, non-radial, off-cooldown, non-attacked line: the build's AC LODF anchored on its own flows
            (P, Q and the per-line S/rho limit of that build), no simulation;
          reconnection of a down, non-attacked, off-cooldown line with no maintenance now / next step: one AC predict of
            fin(T + reconnect) on the do-nothing forecast (the flow half of a prep), at most RECO_RELIEF_CAP per topology.
        Only areas whose line budget the prefix and T left free.  Key = max over live lines of estimated corrected loading /
        own threshold."""
        pc = T['pc']; out = []
        if pc is None: return out
        obs = X['obs']; lim = X['lim']
        oc = pc["oc"]; liveT = np.asarray(oc.line_status, dtype=bool); rhoT = np.asarray(oc.rho, dtype=float)
        PT = np.asarray(pc["P0"], dtype=float); QT = np.asarray(pc["Q0"], dtype=float); L = pc["L"]
        SlimT = np.where(liveT & (rhoT > 1e-4), np.sqrt(PT ** 2 + QT ** 2) / np.maximum(rhoT, 1e-6), 1e6)
        try:
            fT = X['fin'](T['act'])
        except Exception:
            return out
        busy = set(int(self.sub_area[self.or_sub[int(k)]]) for k in np.where((np.asarray(fT._set_line_status) != 0) & ~np.isin(np.arange(self.nl), X.get('mntd_lines', ())))[0])
        cd = np.asarray(obs.time_before_cooldown_line, dtype=int); tnm = np.asarray(obs.time_next_maintenance, dtype=int)
        for k in np.where(liveT)[0]:   # ---- disconnections ----
            k = int(k); a = int(self.sub_area[self.or_sub[k]])
            if cd[k] != 0 or bool(self._atk_now[k]) or a in busy: continue
            if pc["rad"][k] or not np.all(np.isfinite(L["PP"][:, k])): continue   # radial: its outage islands the grid
            Pk = PT + L["PP"][:, k] * PT[k] + L["PQ"][:, k] * QT[k]
            Qk = QT + L["QP"][:, k] * PT[k] + L["QQ"][:, k] * QT[k]
            m = liveT.copy(); m[k] = False
            if not m.any(): continue
            key = float(np.max((np.sqrt(Pk[m] ** 2 + Qk[m] ** 2) / SlimT[m] + corr[m]) / lim[m]))
            if np.isfinite(key): out.append(dict(t=ti, la=self.trips[k], line=k, kind='disc', area=a, key=key))
        nr = 0
        for k in np.where(~liveT)[0]:   # ---- reconnections ----
            k = int(k); a = int(self.sub_area[self.or_sub[k]])
            if k in X.get('mntd_lines', ()): continue   # (MNTD) already out in the shadow grid
            if bool(self._atk_now[k]) or cd[k] != 0 or 0 <= int(tnm[k]) <= 1 or a in busy: continue
            if nr >= RECO_RELIEF_CAP: break
            la = self._s2_reco(k, T['act'])   # (v2) ends on bus 1 unless T sets them
            if not self._s2_legal(X, T['act'] + la): continue
            nr += 1; _s2_cnt('reco_pred')
            try:
                sp = X['base_sim'].predict(X['fin'](T['act'] + la))
                if not getattr(sp, "converged", False): continue
                o2 = sp.current_obs; l2 = np.asarray(o2.line_status, dtype=bool)
                if not l2[k]: continue
                key = float(np.max(_cx(o2.rho)[l2] / lim[l2]))
            except Exception:
                continue
            if np.isfinite(key): out.append(dict(t=ti, la=la, line=k, kind='reco', area=a, key=key))
        return out

    # ===================== (LP) S2 dispatch layer (build_lp.py) =====================
    # Phase C, after COMBO-CLEAR (and DOOMED), before the gate; reached only when nothing has cleared this step.
    # Groups G1..G5 of sizes S2_LP_T0 / S2_LP_KCOMBO / S2_LP_KEX / S2_LP_KLA / S2_LP_KSP (see build_lp.py's header).
    # _s2_lp: units (_s2_lp_units) -> options + LP-screen -> one LP per option (_s2_lp_rows, _s2_lp_run) -> plan action
    # (_s2_lp_action) -> _s2_legal + exact check -> LP-CLEAR commit, else the plans join the gate.
    def _s2_lp_units(self, X, gp):
        """(LP) the controllable units in a FIXED layout [Rgen | every renewable | storage] (so the tie-break index always
        means the same unit) and the bounds of u = the change of injection against the do-nothing forecast fc (MW,
        generator convention).  Every bound holds 0, so u = 0 plus slacks is always feasible.
        OLD (S2_LP_BOX False; the old MILP's): -rd <= u_g <= ru; -fc.gen_p <= u_w <= 0 for a renewable producing in fc;
          storage -min(P_absorb, (Emax - SoC)/dt) <= u_j <= min(P_prod, (SoC - Emin)/dt); a unit disconnected in fc: 0.
        BOX (S2_LP_BOX True; later arm): generators also inside [pmin, pmax] and one ramp of obs.gen_p (the env's rule),
          target within +-(pmax - pmin), not the backend slack, not off in the chronic, not an asked unit with an unmet
          target; the ask a = u + dlt (dlt used only with S2_LP_EMIT: grid2op anchors a first ask on the CURRENT actual
          dispatch, a later one on the target); storage efficiency (ACTIVATE_STORAGE_LOSS); DCROOM row on the net redispatch."""
        gd = self.gd; obs = X['obs']; fc = X['fc']
        R = [int(g) for g in self.Rgen]; W = [int(g) for g in range(gd.n_gen) if gd.gen_renewable[g]]
        nS = (self.n_storage); nR, nW = len(R), len(W); nU = nR + nW + nS
        lo = np.zeros(nU); hi = np.zeros(nU); cst = np.zeros(nU); dlt = np.zeros(nU); kind = np.zeros(nU, dtype=int)
        kind[nR:nR + nW] = 1; kind[nR + nW:] = 2
        tv = np.asarray(fc.topo_vect); gp = np.asarray(gp, dtype=float)
        ru = np.asarray(self.ru, dtype=float); rd = np.asarray(self.rd, dtype=float)
        pmin = np.asarray(self.pmin, dtype=float); pmax = np.asarray(self.pmax, dtype=float)
        dts = float(getattr(obs, "delta_time", 5.0)) / 60.0
        for j, g in enumerate(R):
            cst[j] = float(self.cost[g])
            if int(tv[self.gen_pos[g]]) < 1: continue
            lo[j], hi[j] = -rd[g], ru[g]
        for j, g in enumerate(W):
            jj = nR + j; cst[jj] = float(W_CUR)
            if int(tv[self.gen_pos[g]]) >= 1 and gp[g] > 0.001: lo[jj] = -float(gp[g])
        if nS > 0:
            soc = np.asarray(obs.storage_charge, dtype=float)
            etc = np.ones(nS); etd = np.ones(nS); mg = 0.0
            for j in range(nS):
                jj = nR + nW + j; cst[jj] = float(STORAGE_COST) * dts
                if int(tv[self.storage_pos[j]]) < 1: continue
                emx = max(0.0, float(self.Emax[j] - soc[j]) - mg); emn = max(0.0, float(soc[j] - self.Emin[j]) - mg)
                hi[jj] = min(float(self.P_prod[j]), emn * float(etd[j]) / dts)
                lo[jj] = -min(float(self.P_absorb[j]), emx / (dts * max(float(etc[j]), 1e-6)))
        lo = np.minimum(lo, 0.0); hi = np.maximum(hi, 0.0)
        room = None   # (ZEROENV) the ramp-room box was never active
        Ri = np.arange(nR); Wi = nR + np.arange(nW); Si = nR + nW + np.arange(nS)
        xidx = np.concatenate([Ri, Ri, Wi, Si, Si]).astype(int)
        xsg = np.concatenate([np.ones(nR), -np.ones(nR), -np.ones(nW), np.ones(nS), -np.ones(nS)])
        xu = np.concatenate([hi[Ri], -lo[Ri], -lo[Wi], hi[Si], -lo[Si]])
        xc = cst[xidx]; nx = len(xidx)
        tb = LP_TB_EPS * (1.0 + np.arange(nx) / float(nx))
        busg = np.concatenate([np.asarray(self.gen_sub, dtype=int)[R + W], np.asarray(self.storage_sub, dtype=int)[:nS]])
        posu = np.concatenate([np.asarray(self.gen_pos, dtype=int)[R + W], np.asarray(self.storage_pos, dtype=int)[:nS]])
        return dict(R=R, W=W, nR=nR, nW=nW, nS=nS, nU=nU, lo=lo, hi=hi, cst=cst, dlt=dlt, kind=kind, room=room, dts=dts,
                    xidx=xidx, xsg=xsg, xu=xu, xc=xc, tb=tb, sub=busg, pos=posu, gp=gp)

    def _s2_lp_H(self, U, pc):
        """(LP) d(origin-side P of every line)/d(u) (MW/MW, nl x nU) on the topology of prep pc: SF gathered at each unit's
        bus in pc's own state (identical to SF @ AGW, prep's bus-0 reference; the balance row removes the reference).
        A unit disconnected there has a zero column."""
        k = '_lpH%d' % U['nU']
        if k not in pc:
            tv = np.asarray(pc['oc'].topo_vect); b = tv[U['pos']]; ok = b >= 1
            bus = U['sub'] + (np.where(ok, b, 1) - 1) * self.ns
            SF = pc['SF']; H = np.zeros((SF.shape[0], U['nU'])); ok &= bus < SF.shape[1]
            H[:, ok] = SF[:, bus[ok]]
            pc[k] = H
        return pc[k]

    @staticmethod
    def _s2_lp_reach(C, lb, ub):
        """(LP) valid upper bound of max C.u s.t. lb <= u <= ub, sum(u) = 0 (LP dual evaluated at its exact minimiser,
        one sort per row; the judged design's reach_bal).  Pruning a row whose reach cannot exceed its room is exact."""
        if C.shape[0] == 0: return np.zeros(0)
        o = np.argsort(C, axis=1); Cs = np.take_along_axis(C, o, 1)
        L = np.abs(lb)[o]; Uu = ub[o]
        left = np.cumsum(L, 1) - L
        right = np.cumsum(Uu[:, ::-1], 1)[:, ::-1] - Uu
        j = np.argmax(left + L >= right, axis=1)
        lam = Cs[np.arange(len(C)), j][:, None]
        return np.maximum((C - lam) * ub, (C - lam) * lb).sum(1)

    def _s2_lp_rows(self, X, U, rec, sn, corr):
        """(LP) the rows of one option.  Anchor = its exact record: live line l with p, q, rho from the checked state,
        r_l = rec['r'] = rho + correction (entered once), linearised as the old MILP's coefs() (P-based, Q held):
            rho_l(u) = r_l + a_l H_l u,   a_l = rho_l p_l / S_l^2  (= d|S|/dP / Slim; |S| is convex in P, so the tangent
            under-estimates away from the anchor).
        N-1 row for credible contingency k: the exact post-contingency flows stashed by worstN1_exact (p^k, q^k, rho^k),
        r^k_l = rho^k_l + corr_l, a^k_l = rho^k_l p^k_l / (S^k_l)^2, gradient H + L'PP[:, k] (x) H[k, :] (L' = the option's
        AC line-outage factors, or the DC double-outage update for a disconnection pair); a contingency missing from the stash
        (islanding) or with a radial / non-finite column is skipped.  Bar = _n1lim.get(k, N1).
        An option may carry its own anchor sn['anc'] = dict(P, Q, rho, r, live, cred, n1s) instead of its record's state
        (open for a later option whose flows are estimated, e.g. lines treated as already disconnected).
        Returns blocks: dict(C (rows x nU), room, w (per row), perline), the base gradient, the row mask and the anchor r."""
        an = sn.get('anc')
        if an is None:
            st = rec['st']; an = dict(P=st.p_or, Q=st.q_or, rho=st.rho, r=rec['r'], live=rec['live'], cred=rec.get('cred', []), n1s=rec.get('n1s'))
        live = np.asarray(an['live'], dtype=bool); r = np.asarray(an['r'], dtype=float)
        P = np.asarray(an['P'], dtype=float); Q = np.asarray(an['Q'], dtype=float); rh = np.asarray(an['rho'], dtype=float)
        S2 = P * P + Q * Q; ok = live & (rh > 1e-4) & (S2 > 1e-6) & np.isfinite(r) & np.isfinite(S2)
        H = sn['H']; a = np.where(ok, rh * P / np.where(ok, S2, 1.0), 0.0); G = a[:, None] * H
        if sn.get('mntd_bar') is not None: ok = live & np.isfinite(r) & np.isfinite(S2)   # (MNTD) include every finite live line; zero-flow rows have zero gradient
        lim = X['lim']; L = np.where(ok)[0]; B = []
        if sn.get('mntd_bar') is not None: lim = lim * float(sn['mntd_bar'])   # (MNTD) own-threshold units
        old = str(S2_LP_OBJ).upper() == 'OLD'
        if old:
            B.append(dict(C=G[L], room=lim[L] - r[L], w=np.full(len(L), float(W_BASE)), perline=int(np.sum(X['ovf'] > 0)) >= SLK_MIN_COUNT))
        else:
            cls = np.clip(X['ovf'] - int(globals().get('S2_M6_SHIFT', 0)), 0, 2)
            W2 = np.array([LP_W2_K0, LP_W2_K1, LP_W2_K2], dtype=float)[cls]
            B.append(dict(C=G[L], room=lim[L] - LP_S1_MARGIN - r[L], w=np.full(len(L), float(LP_W1)), perline=True))
            B.append(dict(C=G[L], room=1.0 - r[L], w=W2[L], perline=True))
            B.append(dict(C=G[L], room=2.0 - r[L], w=np.full(len(L), float(LP_W3)), perline=True))
        stash = an.get('n1s') or {}
        n1lim = getattr(self, '_n1lim', None) or {}
        for k in an.get('cred', []) or []:
            k = int(k)
            if k not in stash or not ok[k]: _s2_cnt('lp_n1_skip'); continue
            col = sn['lodf'](k)
            if col is None: _s2_cnt('lp_n1_skip'); continue
            pk, qk, rk_, lsk = stash[k]; S2k = pk * pk + qk * qk
            mk = ok & lsk & (rk_ > 1e-4) & (S2k > 1e-6) & np.isfinite(S2k); mk[k] = False
            Lk = np.where(mk)[0]
            if len(Lk) == 0: continue
            rk = rk_[Lk] + corr[Lk]; ak = rk_[Lk] * pk[Lk] / S2k[Lk]
            Gk = ak[:, None] * (H[Lk] + np.outer(col[Lk], H[k]))
            bar = float(n1lim.get(k, N1_LIMIT))
            if old:
                if not (float(rk.max()) >= N1_INCLUDE or bar < N1_LIMIT): continue
                w = float(W_BASE) if bar < N1_LIMIT else float(W_N1)
            else:
                w = float(LP_WN1)
            B.append(dict(C=Gk, room=bar - rk, w=np.full(len(Lk), w), perline=False))
        return B, G, ok, r

    def _s2_lp_engine(self):
        """(LP) the persistent HiGHS object (created once): serial dual simplex, presolve off, parallel off, seed 0,
        iteration cap.  NEVER time_limit (cumulative on a persistent object) or threads (fails after any earlier HiGHS run
        in the process).  None -> scipy linprog(method='highs-ds') per LP."""
        if getattr(self, '_lp_eng', None) is None:
            eng = False
            try:
                import highspy
                h = highspy.Highs()
                for k_, v_ in (('output_flag', False), ('presolve', 'off'), ('solver', 'simplex'), ('simplex_strategy', 1),
                               ('parallel', 'off'), ('random_seed', 0), ('simplex_iteration_limit', int(LP_ITER_CAP))):
                    h.setOptionValue(k_, v_)
                _v = h.getOptionValue('simplex_scale_strategy'); _v = _v[1] if isinstance(_v, tuple) else _v
                eng = dict(h=h, hp=highspy, scale0=_v)
                _ver = str(h.version()) if hasattr(h, 'version') else '?'
            except Exception:
                eng = None; _ver = 'none'
            try:
                import scipy as _sc; _scv = _sc.__version__
            except Exception:
                _scv = '?'
            print('S2LP-ENGINE path=%s highspy=%s scipy=%s numpy=%s' % ('highspy' if eng else 'scipy-highs-ds', _ver, _scv, np.__version__), flush=True)
            self._lp_eng = eng if eng else False
        return self._lp_eng or None

    def _s2_lp_run(self, U, B):
        """(LP) assemble and solve one option's LP over x = [dp+ | dp- | curtail | sto+ | sto- | slacks] (fixed layout):
            min scale (eurf (cost + tie-break) . x_controls + weights . slacks)
            s.t. C_row (T x) - s_row <= room_row  (per-line slack, or one slack per block),  sum(T x) = 0 (balance),
                 [BOX] room[0] <= sum over generators of u <= room[1],  0 <= x <= xu,  s >= 0.
        Inputs rounded (C 1e-11, room 1e-9); rows whose balanced reach cannot exceed their room are dropped (exact);
        entries whose full-range effect is below 1e-6 are zeroed.  Returns (u, objective without the tie-break, rows kept)
        or None (no optimal status after the fallback chain)."""
        old = str(S2_LP_OBJ).upper() == 'OLD'
        eurf = 1.0 if old else float(LP_WCOST); scale = float(LP_OLD_SCALE) if old else float(LP_M6_SCALE)
        lb, ub = U['lo'], U['hi']; xidx, xsg, xu = U['xidx'], U['xsg'], U['xu']; nx = len(xidx)
        Cs, rooms, ws, sid = [], [], [], []; nsl = 0
        for b in B:
            C = np.round(np.asarray(b['C'], dtype=float), 11); room = np.round(np.asarray(b['room'], dtype=float), 9)
            fin_ = np.all(np.isfinite(C), axis=1) & np.isfinite(room)
            if not fin_.all(): _s2_cnt('lp_row_nonfinite', int((~fin_).sum()))
            keep = np.where(fin_)[0]
            keep = keep[self._s2_lp_reach(C[keep], lb, ub) > room[keep] + 1e-9]
            if len(keep) == 0: continue
            Cs.append(C[keep]); rooms.append(room[keep]); ws.append(np.asarray(b['w'], dtype=float)[keep])
            if b['perline']: sid.append(nsl + np.arange(len(keep))); nsl += len(keep)
            else: sid.append(np.full(len(keep), nsl)); nsl += 1
        m = sum(len(x) for x in rooms)
        Cu = np.vstack(Cs) if m else np.zeros((0, U['nU'])); room = np.concatenate(rooms) if m else np.zeros(0)
        wr = np.concatenate(ws) if m else np.zeros(0); si = np.concatenate(sid).astype(int) if m else np.zeros(0, dtype=int)
        sw = np.zeros(nsl)
        if m: sw[si] = wr   # a block's rows share one weight
        Cx = Cu[:, xidx] * xsg
        if m: Cx[np.abs(Cx) * xu < 1e-6] = 0.0
        box = U['room'] is not None
        nr = m + (2 if box else 0); n = nx + nsl
        A = np.zeros((nr + 1, n)); A[:m, :nx] = Cx
        if m: A[np.arange(m), nx + si] = -1.0
        rl = np.full(nr + 1, -np.inf); ru_ = np.zeros(nr + 1); ru_[:m] = room
        if box:
            gm = (U['kind'][xidx] == 0) * xsg
            A[m, :nx] = gm; ru_[m] = U['room'][1]; A[m + 1, :nx] = -gm; ru_[m + 1] = -U['room'][0]
        A[nr, :nx] = xsg; rl[nr] = 0.0; ru_[nr] = 0.0
        c0 = np.concatenate([U['xc'] * eurf, sw]); cost = np.concatenate([(U['xc'] + U['tb']) * eurf, sw]) * scale
        cl = np.zeros(n); cu = np.concatenate([xu, np.full(nsl, np.inf)])
        x = None; eng = self._s2_lp_engine()
        _m = self._tm[1]; self._T_mark(_m.replace('build', 'solve') if _m.endswith('build') else _m)
        if eng is not None:
            hp = eng['hp']; h = eng['h']
            import scipy.sparse as _sp
            M = _sp.csc_matrix(A)
            lp = hp.HighsLp(); lp.num_col_ = n; lp.num_row_ = nr + 1
            lp.col_cost_ = cost; lp.col_lower_ = cl; lp.col_upper_ = cu; lp.row_lower_ = rl; lp.row_upper_ = ru_
            am = lp.a_matrix_; am.format_ = hp.MatrixFormat.kColwise; am.num_col_ = n; am.num_row_ = nr + 1
            am.start_ = M.indptr.astype(np.int32); am.index_ = M.indices.astype(np.int32); am.value_ = M.data.astype(float)
            h.passModel(lp); h.run(); okst = h.getModelStatus() == hp.HighsModelStatus.kOptimal
            if not okst:   # deterministic fallback chain on the same model: other scaling, primal simplex, IPM
                for k_, v_, d_ in (('simplex_scale_strategy', 4, eng['scale0']), ('simplex_strategy', 4, 1), ('solver', 'ipm', 'simplex')):
                    _s2_cnt('lp_retry'); h.setOptionValue(k_, v_); h.passModel(lp); h.run()
                    okst = h.getModelStatus() == hp.HighsModelStatus.kOptimal; h.setOptionValue(k_, d_)
                    if okst: break
            if okst: x = np.asarray(h.getSolution().col_value, dtype=float)
        else:
            from scipy.optimize import linprog
            ie = np.isfinite(rl)
            res = linprog(cost, A_ub=A[~ie], b_ub=ru_[~ie], A_eq=A[ie], b_eq=ru_[ie], bounds=list(zip(cl, [None if not np.isfinite(v) else float(v) for v in cu])), method='highs-ds')
            if res.status == 0 and res.x is not None: x = np.asarray(res.x, dtype=float)
        self._T_mark(_m)
        if x is None or len(x) != n:
            _s2_cnt('lp_infeasible'); return None
        _s2_cnt('lp_solved')
        u = np.zeros(U['nU']); np.add.at(u, xidx, xsg * x[:nx])
        u = np.clip(np.round(u / LP_RND_MW) * LP_RND_MW, lb, ub)
        return u, float(c0 @ x), m

    def _s2_lp_action(self, U, act, u):
        """(LP) option + dispatch as a grid2op action (the old MILP's mapping): redispatch (g, u_g [+ dlt with EMIT]) for
        |u_g| >= LP_EMIT_RD (incremental, persistent in the target); curtail (w, (fc.gen_p + u_w)/pmax) for a cut >= LP_EMIT_CUR
        (persistent limit); set_storage (j, -u_j) for |u_j| >= LP_EMIT_STO (one-step setpoint, load convention).
        Returns (action, MW sent)."""
        nR, nW = U['nR'], U['nW']; rl, cl, sl = [], [], []; mw = 0.0
        for j in range(nR):
            if abs(u[j]) >= LP_EMIT_RD:
                g = U['R'][j]; a_ = float(u[j] + ((0.0)))
                rl.append((g, float(min(max(a_, -float(self.rd[g])), float(self.ru[g]))))); mw += abs(float(u[j]))
        for j in range(nW):
            if u[nR + j] <= -LP_EMIT_CUR:
                g = U['W'][j]; cl.append((g, float(min(1.0, max(0.0, (U['gp'][g] + u[nR + j]) / float(self.pmax[g])))))); mw += abs(float(u[nR + j]))
        for j in range(U['nS']):
            if abs(u[nR + nW + j]) >= LP_EMIT_STO: sl.append((int(j), float(-u[nR + nW + j]))); mw += abs(float(u[nR + nW + j]))
        d = {}
        if rl: d['redispatch'] = rl
        if cl: d['curtail'] = cl
        if sl: d['set_storage'] = sl
        return (act + self.gd.action_space(d) if d else act), mw

    def _s2_lp(self, X, cands, S1, multi, CB, kept, tops, t0, prep, gp):
        """(LP) the layer (see the header above _s2_lp_units).  Returns the committed action (src LP) or None; plans that
        do not clear are appended to cands (the gate's candidates)."""
        _s2_cnt('lp_steps'); self._T_mark('lp_rank')
        _T = self.__dict__.setdefault('_T', {}); _Tb = dict((k, v) for k, v in _T.items() if k.startswith('lp_')); _tb = time.time()
        U = self._s2_lp_units(X, gp)
        nl = self.nl; corr = _cx(np.zeros(nl)); ak = self._s2_akey
        good = lambda r: (r is not None) and bool(r.get('ok')) and (r.get('en') is not None)
        PC = {}                                   # raw-action content -> prep (None = failed); T0 / T1 / T2 reused
        for T in tops: PC[ak(T['act'])] = T['pc']
        nreco = [0]
        def pc_of(act, reco=False):
            k = ak(act)
            if k in PC: return PC[k]
            if reco:
                if nreco[0] >= RECO_RELIEF_CAP: return None
                nreco[0] += 1; _s2_cnt('lp_reco_prep')
            _m = self._tm[1]; self._T_mark('lp_prep'); pc = self._s2_prep(X, prep, act); self._T_mark(_m)
            _s2_cnt('lp_prep' if pc is not None else 'lp_prep_fail'); PC[k] = pc
            return pc
        def sens_prep(pc):   # the topology's own prep: AC sensitivities and AC line-outage factors
            if pc is None: return None
            LL = pc['L']; rad = pc['rad']
            def lodf(k):
                if rad[k] or not np.all(np.isfinite(LL['PP'][:, k])): return None
                return LL['PP'][:, k]
            sn = dict(H=self._s2_lp_H(U, pc), lodf=lodf, how='prep')
            if X.get('mntd_mode'): sn.update(mntd_bar=float(S2_MNTD_BAR))   # (MNTD)
            return sn
        def sens_rank1(pc, k):   # disconnection of k on the topology of pc: DC rank-1 outage update of its prep
            if pc is None: return None
            PP = pc['L']['PP']; rad = pc['rad']
            if rad[k] or not np.all(np.isfinite(PP[:, k])): return None
            _m = self._tm[1]; self._T_mark('lp_rank1'); _s2_cnt('lp_rank1')
            H0 = self._s2_lp_H(U, pc)
            H = H0 + np.outer(PP[:, k], H0[k, :])       # H' = H_T + L_T[:, k] (x) H_T[k, :]
            def lodf(m):   # the post-k network's outage factors: DC double-outage update (PP)
                if m == k or rad[m] or not np.all(np.isfinite(PP[:, m])): return None
                den = 1.0 - PP[m, k] * PP[k, m]
                if not np.isfinite(den) or abs(den) < 1e-3: return None   # m is radial once k is out
                return (PP[:, m] + PP[:, k] * PP[k, m]) / den
            self._T_mark(_m)
            sn = dict(H=H, lodf=lodf, how='rank1')
            if X.get('mntd_mode'): sn.update(mntd_bar=float(S2_MNTD_BAR))   # (MNTD)
            return sn
        npair = len(kept)
        pairs = [(CB[i], kept[i]) for i in range(min(npair, len(CB))) if good(CB[i])]   # CB[i] is kept[i]'s exact check
        pinfo = dict((id(r), p) for r, p in pairs)
        combos = sorted([r for r in CB[npair:] if good(r)], key=lambda r: (r['key'], r.get('nact', 0)))
        splits = sorted([r for r in list(S1) + ([multi] if multi is not None else []) if good(r)], key=lambda r: r['key'])
        def sens_of(r):
            p = pinfo.get(id(r))
            if p is None: return sens_prep(pc_of(r['act']))
            if p['kind'] == 'disc': return sens_rank1(tops[p['t']]['pc'], int(p['line']))
            return sens_prep(pc_of(r['act'], reco=True))
        sol = {}                                  # id(record) -> (u, obj, rows, G, ok, r0) or None: the LP of that option (screen = plan)
        def lp_of(r, sn, bucket):
            if id(r) not in sol:
                _m = self._tm[1]; self._T_mark(bucket)
                try:
                    Bk, G, okl, r0 = self._s2_lp_rows(X, U, r, sn, corr)
                    out = self._s2_lp_run(U, Bk)
                    sol[id(r)] = None if out is None else out + (G, okl, r0)
                except Exception:
                    sol[id(r)] = None; _s2_cnt('lp_err')
                    if S2_DIAG.get('lp_err', 0) <= 3: print('S2 LP-ERROR step=%d %s' % (X['step'], _s2_tb.format_exc()[-1500:]), flush=True)
                self._T_mark(_m)
            return sol[id(r)]
        # ---- the option set: G1..G5, deduplicated; a short group stays short (never filled from another group) ----
        sel = []; seen = set(); scr = {}
        def fpk(r):   # the exact state's fingerprint: two topologies with the same flows everywhere give the same LP
            return (np.asarray(r['live'], dtype=bool).tobytes(), np.round(np.asarray(r['r'], dtype=float), 5).tobytes())
        def dup(r): return ak(r['act']) in seen or fpk(r) in seen
        def pick(gi, order, want):
            got = 0
            for r, sf in order:
                if got >= want: break
                if dup(r): _s2_cnt('lp_dup'); continue
                sn = sf() if callable(sf) else sf
                if sn is None: _s2_cnt('lp_nosens'); continue
                seen.add(ak(r['act'])); seen.add(fpk(r)); sel.append((gi, r, sn)); got += 1
            return got
        def screen(pool, sensf):   # LP-screen: the candidate's own LP optimum (lower first), ties -> the lower exact M6 key
            rk = []
            for r in pool:
                if dup(r): continue
                sn = sensf(r)
                if sn is None: continue
                o = lp_of(r, sn, 'lp_screen'); _s2_cnt('lp_screened')
                if o is None: continue
                scr[id(r)] = o[1]; rk.append((round(o[1], 6), r['key'], len(rk), r, sn))
            rk.sort(key=lambda z: z[:3])
            return [(z[3], z[4]) for z in rk]
        T0r = t0 if t0 is not None else X['dn']
        pick(1, [(T0r, lambda: sens_prep(tops[0]['pc']))] if (good(T0r) and tops) else [], S2_LP_T0)
        pick(2, [(r, (lambda r=r: sens_of(r))) for r in combos], S2_LP_KCOMBO)
        g3 = sorted(splits + [r for r, _ in pairs], key=lambda r: (r['key'], r.get('nact', 0)))
        pick(3, [(r, (lambda r=r: sens_of(r))) for r in g3], S2_LP_KEX)
        if S2_LP_KLA > 0: pick(4, screen([r for r, _ in pairs], sens_of), S2_LP_KLA)
        if S2_LP_KSP > 0:
            pool = splits[:LP_SPLIT_POOL] + [r for r in splits[LP_SPLIT_POOL:] if PC.get(ak(r['act'])) is not None]
            pick(5, screen(pool, lambda r: sens_prep(pc_of(r['act']))), S2_LP_KSP)
        if S2_LP_MAX is not None and len(sel) > int(S2_LP_MAX): _s2_cnt('lp_capped', len(sel) - int(S2_LP_MAX)); sel = sel[:int(S2_LP_MAX)]
        if X.get('mntd_mode'): sel = sel[:int(S2_MNTD_OPTS)]; _s2_cnt('mntd_options', len(sel))   # (MNTD)
        if X.get('mntd_mode'):
            for _gi, _r, _sn in sel: _sn['mntd_bar'] = float(S2_MNTD_BAR)   # (MNTD)
        for gi, _r, _sn in sel: _s2_cnt('lp_sel_g%d' % gi)
        # ---- one LP per option (a screened option reuses its LP); the best S2_LP_CHECK_N plans by LP objective (ties: the
        #      option's lower exact M6 key, then option order) go through _s2_legal and the exact check, the rest are dropped ----
        opts = []
        for oi, (gi, r, sn) in enumerate(sel):
            o = lp_of(r, sn, 'lp_build')
            if o is not None: opts.append((oi, gi, r, sn, o))
        if X.get('mntd_mode'): pass   # (MNTD) every shadow option receives both exact checks
        elif S2_LP_CHECK_N is not None and len(opts) > int(S2_LP_CHECK_N):
            ko = set(z[0] for z in sorted(opts, key=lambda z: (round(z[4][1], 6), z[2]['key'], z[0]))[:int(S2_LP_CHECK_N)])
            _s2_cnt('lp_unchecked', len(opts) - len(ko)); opts = [z for z in opts if z[0] in ko]
        plans = []; logp = []; mntd_log = []   # (MNTD)
        for oi, gi, r, sn, o in opts:
            u, obj, nrow, G, okl, r0 = o
            ma, mw = self._s2_lp_action(U, r['act'], u)
            pred = r0 + G @ u; prel = float(np.max(pred[okl] / X['lim'][okl])) if okl.any() else 9.99
            if mw <= 0.0: _s2_cnt('lp_nodisp')
            self._T_mark('lp_exact')
            if self._s2_legal(X, ma):
                rec = self._s2_ev(X, ma)
            else:
                rec = self._s2_fail(); _s2_cnt('lp_illegal')
            _s2_cnt('lp_plans')
            rec.update(act=ma, src='LP', subs=r.get('subs', frozenset()), nact=r.get('nact', 0), gsrc='BEST-LP%d' % gi, lpg=gi, lpmw=mw, lpo=oi)
            if not rec['ok']: _s2_cnt('lp_plan_fail')
            elif rec['clear']: _s2_cnt('lp_clear')
            if mw > 0.0 or not rec['ok']: plans.append(rec)   # a plan without dispatch IS its option, already a candidate
            if X.get('mntd_mode'):
                _s2_cnt('mntd_plans')
                curX = X['mntd_current']; cur = self._s2_ev(curX, ma) if self._s2_legal(curX, ma) else self._s2_fail('legal')
                cr = float(cur['rrel']) if cur['ok'] else 9.99
                new3 = bool(cur['ok'] and np.any((curX['ovf'] >= 3) & cur['live'] & (cur['r'] > 1.0)
                            & (curX['dn']['r'] <= 1.0)))
                safe = bool(cur['ok'] and cr <= float(S2_MNTD_CUR_MAX) and not new3)
                if not safe: _s2_cnt('mntd_unsafe')
                clean = bool(rec['ok'] and rec['rrel'] < float(S2_MNTD_BAR) and rec['en'] < N1_LIMIT)
                if clean and safe: _s2_cnt('mntd_clean')
                rec.update(mntd_safe=safe, mntd_current=cr, mntd_clean=clean)
                plans.append(rec)
                mntd_log.append(dict(group=gi, origin=r.get('src', 'T0'), topology=r.get('subs'),
                                     screen=('LP' if id(r) in scr else 'exact'), sensitivity=sn['how'],
                                     estimate=prel, doomed_exact=(float(rec['rrel']) if rec['ok'] else None),
                                     doomed_n1=(float(rec['en']) if rec['ok'] else None),
                                     current_exact=(cr if cur['ok'] else None), clean=clean,
                                     safe=safe, why=rec.get('why') or cur.get('why'), obj=float(obj), mw=float(mw)))
            logp.append('g%d:%s:%s obj=%.6g mw=%.1f rows=%d scr=%s pre=%.3f pred=%.4f exact=%s clr=%d sc=%.4f' % (
                gi, r.get('src', 'T0'), sn['how'], obj, mw, nrow, ('%.6g' % scr[id(r)]) if id(r) in scr else '-',
                float(r['rrel']), prel, ('%.4f' % rec['rrel']) if rec['ok'] else 'FAIL', int(bool(rec.get('clear'))),
                float(rec['sc']) if rec['ok'] and rec.get('sc') is not None else 9.99))
            self._T_mark('lp_rank')
        if X.get('mntd_mode'): return dict(plans=plans, options=mntd_log)   # (MNTD) caller applies the source-decision gate
        cl = [p for p in plans if p['ok'] and p['clear']]
        b = min(cl, key=lambda p: (p['key'], p['lpmw'], p['nact'], p['lpo'])) if cl else None
        if _s2_steplog():
            _d = dict((k, 1000.0 * (v - _Tb.get(k, 0.0))) for k, v in _T.items() if k.startswith('lp_'))
            print('S2LP step=%d obj=%s sel=%s nlp=%d plans=%d clear=%d commit=%s ms=%.1f rank=%.1f rank1=%.1f prep=%.1f screen=%.1f build=%.1f solve=%.1f exact=%.1f dn_sc=%.4f | %s' % (
                X['step'], S2_LP_OBJ, ''.join(str(g) for g, _r, _s in sel), len(sol), len(logp), len(cl), ('g%d' % b['lpg']) if b is not None else '-',
                1000.0 * (time.time() - _tb), _d.get('lp_rank', 0.0), _d.get('lp_rank1', 0.0), _d.get('lp_prep', 0.0), _d.get('lp_screen', 0.0),
                _d.get('lp_build', 0.0), _d.get('lp_solve', 0.0), _d.get('lp_exact', 0.0), float(X['dn']['sc']), ' ; '.join(logp)), flush=True)
        if b is not None:
            _s2_cnt('lp_commit_g%d' % b['lpg'])
            return self._s2_out(X, b['act'], 'LP', b)
        cands.extend([p for p in plans if p['ok'] and p.get('en') is not None])
        return None

    # ===================== (MNTD) post-outage shadow pass =====================
    def _s2_mntd_lines(self, X):
        if not X['dn'].get('ok'): return []
        obs = X['obs']; tnm = np.asarray(obs.time_next_maintenance, dtype=int)
        live = np.asarray(obs.line_status, dtype=bool)   # (MNTD) countdown 1 is still live in the observed grid
        D = [int(k) for k in np.where(live & (tnm > 0) & (tnm <= int(S2_MNTD_W)))[0]]
        return sorted(D, key=lambda k: (int(tnm[k]), k))[:int(S2_MNTD_MAX)]

    def _s2_mntd_prepare(self, X):
        D = self._s2_mntd_lines(X)
        if not D: return
        t0 = time.time(); oldstage = self._tm[1]
        self._T_mark('mntd')
        probe = dict(step=X['step'], lines=D, certain={str(self.gd.name_line[k]): int(X['obs'].time_next_maintenance[k]) for k in D},
                     options=[], committed=None)
        self._mntd_probe = probe
        try:
            disc = self.gd.action_space({'set_line_status': [(k, -1) for k in D]})
            fa0 = X['fin'](self.do_nothing) + disc
            res = X['obs'].simulate(fa0, time_step=1)
            inf = res[3] if len(res) > 3 and isinstance(res[3], dict) else {}
            if (len(res) > 2 and res[2]) or any(inf.get(k) for k in ('is_illegal', 'is_ambiguous', 'failed_redispatching', 'exception')):
                _s2_cnt('mntd_diverged'); probe['diverged'] = 'illegal=%d ambiguous=%d redisp=%d exception=%d' % tuple(bool(inf.get(k)) for k in ('is_illegal', 'is_ambiguous', 'failed_redispatching', 'exception')); return   # (ZE2) named flags only
            st = res[0]; live = np.asarray(st.line_status, dtype=bool)
            if np.any(live[D]) or not np.all(np.isfinite(np.asarray(st.rho)[live])):
                _s2_cnt('mntd_diverged'); probe['diverged'] = 'outage or nonfinite'; return
            rec = self._s2_state(X, st)
            if not rec['ok']:
                _s2_cnt('mntd_diverged'); probe['diverged'] = 'state'; return
            probe['doomed_dn'] = float(rec['rrel'])
            if rec['rrel'] <= float(S2_MNTD_BAR):
                _s2_cnt('mntd_fine'); return
            key = tuple((k, X['step'] + int(X['obs'].time_next_maintenance[k])) for k in D)
            if self.__dict__.setdefault('_mntd_fires', {}).get(key, 0) >= int(S2_MNTD_MAXSTEP):
                _s2_cnt('mntd_deferred'); probe['deferred'] = 'maxstep'; return
            _s2_cnt('mntd_steps'); _s2_cnt('mntd_lines', len(D))
            S2_DIAG['mntd_over'] = max(float(S2_DIAG.get('mntd_over', 0.0)), float(rec['rrel']))
            X['mntd_data'] = dict(lines=D, disc=disc, st=st, key=key)
        except Exception:
            _s2_cnt('mntd_err')
            if S2_DIAG.get('mntd_err', 0) <= 3: print('S2 MNTD-ERROR step=%d %s' % (X['step'], _s2_tb.format_exc()[-1800:]), flush=True)
        finally:
            self._T_mark(oldstage); self._T['mntd'] = self._T.get('mntd', 0.0) + time.time() - t0

    def _s2_mntd(self, X, ordinary, prep, legal):
        data = X.get('mntd_data')
        if data is None: return ordinary
        D = data['lines']; disc = data['disc']; st = data['st']
        oldstage = self._tm[1]; oldprefix = self._gpt_a_prefix; oldgrid = self._nwt_grid
        doom_t0 = time.time(); doom_prev = self.__dict__.setdefault('_T', {}).get('mntd', 0.0)
        self._T_mark('mntd')
        probe = self._mntd_probe; probe['ordinary'] = ordinary[1].get('status'); probe['committed'] = probe['ordinary']
        try:
            self._gpt_a_prefix = None
            ds = st.get_simulator(); X['keep'].append(ds)
            gm = ds.backend._grid; self._nwt_grid = gm
            Y = np.array(gm.get_Ybus().todense()); P = np.asarray(st.p_or, dtype=float); Q = np.asarray(st.q_or, dtype=float)
            rho = np.asarray(st.rho, dtype=float); live = np.asarray(st.line_status, dtype=bool)
            Slim = np.where(live & (rho > 1e-4), np.sqrt(P * P + Q * Q) / np.maximum(rho, 1e-6), 1e6)
            base_fin = X['fin']
            def fin3(a):
                fa = base_fin(a)
                if np.any(np.asarray(fa._set_line_status)[D] == 1): raise ValueError('maintained line reconnected')
                return fa + disc
            def prep3(a):
                return prep(a if np.all(np.asarray(a._set_line_status)[D] == -1) else a + disc)
            Z = dict(X); Z.update(fc=st, base_sim=X['base_sim'], fin=fin3, base_bridges=self._bridge_lines(st),
                                  dn=None, evc={}, n1c={}, nsim=0, nn1=0, keep=X['keep'], mntd_mode=True,
                                  mntd_lines=tuple(D), mntd_current=X)
            Z['dn'] = self._s2_n1(Z, self._s2_state(Z, st)); Z['dn']['act'] = self.do_nothing
            if not Z['dn']['ok']:
                _s2_cnt('mntd_diverged'); probe['diverged'] = 'state'; return ordinary
            dn3 = prep3(fin3(self.do_nothing))
            if dn3 is None:
                _s2_cnt('mntd_diverged'); probe['diverged'] = 'prep'; return ordinary
            ans = self._s2_phase_c(Z, dn3, prep3, legal, Y, P, Q, Slim, np.where(live)[0],
                                   np.asarray(st.gen_p, dtype=float), np.asarray(st.load_p, dtype=float))
            if not isinstance(ans, dict): return ordinary
            probe['options'] = ans['options']
            eligible = [p for p in ans['plans'] if p['ok'] and p['mntd_safe'] and p.get('en') is not None]
            clean = [p for p in eligible if p['mntd_clean']]
            pool = clean if clean else [p for p in eligible if p['rrel'] <= probe['doomed_dn'] - 0.05]
            if not pool:
                _s2_cnt('mntd_deferred'); probe['deferred'] = 'no acceptable plan'; return ordinary
            best = min(pool, key=lambda p: (p['key'], p['lpmw'], p['nact'], p['lpo']))
            label = 'MNTD' if best['mntd_clean'] else 'BEST-MNTD'
            full = base_fin(best['act'])
            self._gpt_a_prefix = None
            _s2_cnt('mntd_commit'); probe['committed'] = label; probe['winner'] = best['lpo']
            self._mntd_fires[data['key']] = self._mntd_fires.get(data['key'], 0) + 1
            probe['reason'] = 'under post-outage bar' if best['mntd_clean'] else 'improved post-outage max by 0.05'
            return self._s2_out(X, full, label, best)
        except Exception:
            _s2_cnt('mntd_err')
            if S2_DIAG.get('mntd_err', 0) <= 3:
                print('S2 MNTD-ERROR step=%d %s' % (X['step'], _s2_tb.format_exc()[-1800:]), flush=True)
            return ordinary
        finally:
            self._gpt_a_prefix = oldprefix; self._nwt_grid = oldgrid; self._T_mark(oldstage)
            self._T['mntd'] = doom_prev + time.time() - doom_t0   # (MNTD) entire shadow pass, including its source stages

    def _s2_phase_c(self, X, dn, prep, legal, Y0, P0, Q0, Slim, on, gp, lp):
        """Phase C (insecure): RESTORE-CLEAR, prefix, screen, STAGE 1, MULTI, topologies, line actions, COMBO-CLEAR,
        [DOOMED], the best-beats-do-nothing gate, BEST / REJECT.  dn = the source's prep(do_nothing) (None: the stages
        that need the linearisation are skipped)."""
        obs = X['obs']; fc = X['fc']; dnr = X['dn']; nl = self.nl; lim = X['lim']; ovf = X['ovf']
        corr = _cx(np.zeros(nl)); _s2_cnt('insecure')
        is_panic = bool(np.any(ovf >= PANIC_OVFL_COUNTER))
        # ---- (C1) targets of the linearised do-nothing, as the source builds them ----
        O_base, O_n1 = [], []
        if dn is not None:
            rbx = np.sqrt(dn["P0"] ** 2 + dn["Q0"] ** 2) / Slim + corr
            O_base = [int(l) for l in on if rbx[l] > lim[l]]
            if dnr['ok'] and dnr['en'] > N1_LIMIT:
                n1dn = {}
                for k in dnr['cred']:
                    if dn["rad"][k] or not np.all(np.isfinite(dn["L"]["PP"][:, k])): continue
                    P0k = dn["P0"] + dn["L"]["PP"][:, k] * dn["P0"][k] + dn["L"]["PQ"][:, k] * dn["Q0"][k]
                    Q0k = dn["Q0"] + dn["L"]["QP"][:, k] * dn["P0"][k] + dn["L"]["QQ"][:, k] * dn["Q0"][k]
                    n1dn[k] = np.sqrt(P0k ** 2 + Q0k ** 2) / Slim + corr
                _bar = lambda k: float(self._n1lim.get(int(k), N1_LIMIT))
                O_n1 = sorted([(k, int(l)) for k in n1dn for l in on if int(l) != k and n1dn[k][l] > _bar(k)],
                              key=lambda kl: -(n1dn[kl[0]][kl[1]] / _bar(kl[0])))[:N_CONT]
        # ---- (C2) RESTORE-CLEAR: the clearing combination with the lowest corrected worst loading (ties: more restorations) ----
        self._T_mark('restore_clear')
        C = self._s2_combos(X)
        for c in sorted([c for c in C if c['bclear']], key=lambda c: (c['rmax'], -c['nrest'])):
            if self._s2_n1(X, c)['clear']:
                if not X.get('mntd_mode'): return self._s2_out(X, c['act'], 'RESTORE-CLEAR', c)
        # ---- (C3) prefix: no re-mesh in an overloaded area; worst loading not above do-nothing's; N-1 kept ----
        self._T_mark('prefix')
        ovA = set(int(self.sub_area[self.or_sub[int(l)]]) for l in np.where(dnr['live'] & (dnr['r'] >= lim))[0]) if dnr['ok'] else set()
        pre = None
        for c in sorted([c for c in C if c['rmax'] <= dnr['rmax'] and not any(int(self.sub_area[x]) in ovA for x in c['ss'])],
                        key=lambda c: (c['rmax'], -c['nrest'])):
            self._s2_n1(X, c)
            if c['en'] < N1_LIMIT or (dnr['en'] >= N1_LIMIT and c['en'] <= dnr['en']):
                pre = c; break
        cands = []   # every candidate tried WITH the prefix: they all compete as "best"
        t0 = None
        if pre is not None:
            self._gpt_a_prefix = self._mnt_strip(obs, self._atk_strip(obs, pre['act'])).copy()   # fin() attaches it from here on
            _s2_cnt('prefix')
            t0 = dict(pre); t0.update(act=self.do_nothing, src='T0', subs=frozenset(), nact=0)   # T0 = do-nothing + prefix
            cands.append(t0)
        # ---- (C4) screen ----
        self._T_mark('screen')
        stS = fc   # the state every screened config will be exact-checked on: do-nothing + prefix
        if pre is not None:
            try:
                _simS = pre['st'].get_simulator(); X['keep'].append(_simS)   # keep the simulator alive while Newton uses its grid
                self._nwt_grid = _simS.backend._grid; stS = pre['st']
            except Exception:
                _s2_cnt('screen_nopfxgrid')
        short = []
        if dn is not None:
            psubs = set(pre['ss']) if pre is not None else set()
            extra = []; tvo = np.asarray(obs.topo_vect)
            for s in range(self.ns):   # re-meshes of the split substations join the pool as ordinary configs
                if s in psubs or int(obs.time_before_cooldown_sub[s]) != 0: continue
                if not np.any(tvo[self.pos2sub == s] == 2): continue
                rem = self._remesh_action(obs, s)
                if rem is not None and self._s2_legal(X, rem): extra.append((rem, s))
            n1s = None
            short = self._split_screen(O_base, O_n1, dn["L"]["PP"], P0, Q0, Slim, on, Y0, dn, gp, lp, stS, X['base_bridges'], legal, is_panic,
                                       s2=dict(extra=extra, lim=lim, per_area=SWITCH_PREP_CAP, n1=n1s))
            _s2_cnt('screen')
        # ---- (C5) STAGE 1: the shortlist in global Newton rank order, with the prefix ----
        self._T_mark('stage1')
        S1 = []; per = {}; vcap = VERIFY_PER_AREA * (PANIC_FACTOR if is_panic else 1)
        for it in short:
            if per.get(it['area'], 0) >= vcap: continue
            per[it['area']] = per.get(it['area'], 0) + 1
            rec = self._s2_ev(X, it['act']); _s2_cnt('stage1')
            rec.update(act=it['act'], subs=frozenset([it['sub']]), area=it['area'], src='STAGE1', nact=1, nkey=it['key'], remesh=it['remesh'])
            S1.append(rec); cands.append(rec)
            if _s2_estlog():
                print('S2EST step=%d kind=%s key=%.4f exact=%.4f exact_n1=%.4f ok=%d' % (X['step'], 'nwt_rm' if it['remesh'] else 'nwt', it['key'],
                      rec['rrel'], (rec['en'] / N1_LIMIT) if rec['ok'] else 9.99, int(rec['ok'])), flush=True)
            if S2_STOP_M > 0 and rec['clear'] and (rec['rrel'] <= 1.0 - S2_STOP_M) and (rec['n1raw'] is not None) and (rec['n1raw'] <= N1_LIMIT - S2_STOP_N1M):
                _s2_cnt('stop_margin'); break   # (STOP) a clear with margin: the best clearing one checked so far commits below
        cl = [r for r in S1 if r['clear']]
        if cl:
            b = min(cl, key=lambda r: r['key'])
            if not X.get('mntd_mode'): return self._s2_out(X, b['act'], 'STAGE1', b)
        # ---- (C6) MULTI: the best config of each area (that beats do-nothing) combined, with the prefix ----
        self._T_mark('multi')
        multi = None; bpa = {}
        for r in S1:
            if r['ok'] and r['key'] < dnr['key'] and (r['area'] not in bpa or r['key'] < bpa[r['area']]['key']): bpa[r['area']] = r
        if len(bpa) >= 2:
            parts = [bpa[a] for a in sorted(bpa)]; comp = parts[0]['act']
            for p in parts[1:]: comp = comp + p['act']
            if self._s2_legal(X, comp):
                multi = self._s2_ev(X, comp); _s2_cnt('multi')
                multi.update(act=comp, subs=frozenset().union(*[p['subs'] for p in parts]), src='MULTI', nact=len(parts))
                cands.append(multi)
                if multi['clear']:
                    if not X.get('mntd_mode'): return self._s2_out(X, comp, 'MULTI', multi)
        # ---- (C7) topologies: T0 = do-nothing + prefix; T1 = the best-scored Stage 1 / MULTI result; T2 = the next best on another substation set ----
        self._T_mark('topo_prep')
        tpool = sorted([r for r in S1 + ([multi] if multi is not None else []) if r['ok']], key=lambda r: r['key'])
        T1 = tpool[0] if tpool else None
        T2 = next((r for r in tpool[1:] if r['subs'] != T1['subs']), None) if T1 is not None else None
        tops = [dict(name='T0', act=self.do_nothing, subs=frozenset(), pc=(dn if pre is None else self._s2_prep(X, prep, self.do_nothing)))]
        for nm, T in (('T1', T1), ('T2', T2)):
            if T is not None: tops.append(dict(name=nm, act=T['act'], subs=T['subs'], pc=self._s2_prep(X, prep, T['act'])))
        # ---- (C8) line actions on every topology, pooled and ranked together; the top S2_LA_PER_AREA per area kept ----
        self._T_mark('line_est')
        pairs = []
        for ti, T in enumerate(tops): pairs += self._s2_line_est(X, ti, T, corr)
        pairs.sort(key=lambda p: p['key'])   # stable: ties keep T0 / T1 / T2, disconnect / reconnect, line order
        kept = []; cnt = {}
        for p in pairs:
            if cnt.get(p['area'], 0) >= S2_LA_PER_AREA: continue
            if p['kind'] == 'disc' and self._s2_disc_radial(X, tops[p['t']], p['line']): _s2_cnt('la_radial'); continue   # (v2) the exact check would fail it
            if not self._s2_legal(X, tops[p['t']]['act'] + p['la']): continue
            cnt[p['area']] = cnt.get(p['area'], 0) + 1; kept.append(p)
        _s2_cnt('la_est', len(pairs)); _s2_cnt('la_kept', len(kept))
        # ---- (C9) COMBO-CLEAR: each kept pair, and per topology its best kept action in each area combined ----
        self._T_mark('combo')
        CB = []
        for p in kept:
            T = tops[p['t']]; act = T['act'] + p['la']
            rec = self._s2_ev(X, act); rec.update(act=act, src='COMBO', subs=T['subs'], nact=len(T['subs']) + 1)
            CB.append(rec)
            if _s2_estlog():
                print('S2EST step=%d kind=%s top=%s key=%.4f exact=%.4f ok=%d' % (X['step'], p['kind'], T['name'], p['key'], rec['rrel'], int(rec['ok'])), flush=True)
        for ti, T in enumerate(tops):
            ba = {}
            for p in kept:   # kept is in key order: the first per area is the topology's best in that area
                if p['t'] == ti and p['area'] not in ba: ba[p['area']] = p
            if len(ba) < 2: continue
            act = T['act']
            for a in sorted(ba): act = act + ba[a]['la']
            if not self._s2_legal(X, act): continue
            rec = self._s2_ev(X, act); rec.update(act=act, src='COMBO', subs=T['subs'], nact=len(T['subs']) + len(ba))
            CB.append(rec)
        cands += CB; _s2_cnt('combo', len(CB))
        cl = [r for r in CB if r['clear']]
        if cl:
            b = min(cl, key=lambda r: (r['key'], r['nact']))
            if not X.get('mntd_mode'): return self._s2_out(X, b['act'], 'COMBO', b)
        if X.get('mntd_mode'): return self._s2_lp(X, cands, S1, multi, CB, kept, tops, t0, prep, gp)   # (MNTD) source candidates on doomed grid
        # ---- (C10) DOOMED (feature d): a line at counter >= S2_DOOMED_CNT still overloaded in the best candidate trips next step anyway ----
        # ---- (LP) dispatch layer: only when nothing has cleared (every clear above has returned) ----
        try:
            _lpo = self._s2_lp(X, cands, S1, multi, CB, kept, tops, t0, prep, gp)
        except Exception:
            _lpo = None; _s2_cnt('lp_exc')
            if S2_DIAG.get('lp_exc', 0) <= 3: print('S2 LP-EXC step=%d %s' % (X['step'], _s2_tb.format_exc()[-1500:]), flush=True)
        if _lpo is not None: return _lpo
        # ---- gate: does the best-scored candidate (with its prefix) beat do-nothing by more than MIN_GAIN? ----
        self._T_mark('final')
        okc = [r for r in cands if r['ok'] and r.get('en') is not None]
        if okc:
            b = min(okc, key=lambda r: r['key'])
            if b['sc'] < dnr['sc'] - MIN_GAIN:
                return self._s2_out(X, b['act'], b.get('gsrc', 'BEST'), b)   # (LP) gsrc only on LP plans
        return self._s2_out(X, self.do_nothing, 'REJECT', t0 if t0 is not None else dnr)   # the prefix alone if there is one

    def decide(self, obs):
        _CA_NOW[0] = np.zeros(0)   # (CA) no stale vector if decide() returns early
        self._n1lim = {}   # (FIX1 F9) no stale KLB bars from an earlier step
        _T = self.__dict__.setdefault('_T', {}); self._tm = [time.time(), 'phaseA']   # (TIME)
        self._ovf_now = np.asarray(obs.timestep_overflow, dtype=int)   # (NWTEP)
        gd = self.gd; do_nothing = self.do_nothing
        self._gpt_a_prefix=None
        ns = self.ns; nl = self.nl
        or_sub = self.or_sub; ex_sub = self.ex_sub; or_pos = self.or_pos; ex_pos = self.ex_pos
        gen_sub = self.gen_sub; gen_pos = self.gen_pos; load_sub = self.load_sub; load_pos = self.load_pos
        pos2sub = self.pos2sub; incident = self.incident; trips = self.trips
        ru = self.ru; rd = self.rd; pmin = self.pmin; pmax = self.pmax; cost = self.cost
        Rgen = self.Rgen; BY_SUB = self.BY_SUB
        sub_of = self.sub_of; _ll = self._ll; _gbbp = self._gbbp; _fixedV = self._fixedV
        _redM = self._redM; flowsens = self.flowsens; worstN1_exact = self.worstN1_exact
        n_sto = (self.n_storage)
        # ---- (P2) online forecast-error calibration: realised loading (obs.rho) vs last step's forecast (fc.rho) ----
        if int(getattr(obs, "current_step", 1)) == 0:
            # (S1-F1) per-EPISODE reseed. The scorer plays every chronic on ONE agent instance
            # (Runner.init_env -> copy.copy(self.agent) is SHALLOW, so this RandomState object is
            # shared; BaseAgent.seed only touches space_prng/action_space). Without this the SMART
            # RESCUE config sample depends on every earlier episode's searches -- at sub 48 the
            # tried set is 0% overlapping after a single earlier search -- so the server commits a
            # different rescue action than the (fresh-agent) bench measures.
            # (S1-F11) the fire counters mean "firings used in the CURRENT attack episode"; left at
            # their cap by a week that died mid-attack they disarm the next chronic's first attack.
            # (P6) mirror _reset_redispatching (baseEnv.py:2060-2068): the env keeps
            # _already_modified_gen across steps and resets it on env.reset and nowhere else,
            # so our mirror of it resets at exactly the same point.
            self._econ_asked = np.zeros(int(self.gd.n_gen), dtype=bool); self._econ_pend = {}
            self._fc_rho_prev = None; self._rho_corr = np.zeros(nl)
            self._atk_now[:] = False
            self._atk_onset[:] = -1; self._atk_probe[:] = -(10**9); self._prev_ls = None
        # ---- (v7) OBSERVATION-ONLY attack tracker (no env internals) ----
        # ONSET is visible: an attackable line IN service drops with (near-)zero reconnect cooldown.
        # Only the opponent does that: my own disconnects set cd=3, overflow trips cd=12,
        # maintenance sets cd=duration with time_next_maintenance==0.
        # END is invisible (memoryless opponent + the MultiArea duration=1 bug hides the cooldown):
        #   HOLD  ATK_MIN_HOLD steps  (published minimum duration - a probe cannot succeed sooner),
        #   PROBE one reconnect every ATK_PROBE_EVERY steps (still on -> opponent re-kills it, hold resumes),
        #   FREE  past ATK_MAX_DUR    (published cap - the attack is certainly over).
        _now = int(getattr(obs, "current_step", 0))
        _ls = np.asarray(obs.line_status, dtype=bool)
        _cd = np.asarray(obs.time_before_cooldown_line, dtype=int)
        self._atk_drop_now = False                                 # (AX) an attack landed since last step
        if self._prev_ls is not None:
            for _k in np.where(self._prev_ls & (~_ls))[0]:
                _k = int(_k)
                if (_k in self._atk_set) and _cd[_k] <= 1 and int(obs.time_next_maintenance[_k]) != 0:
                    self._atk_onset[_k] = _now                     # fresh drop with no cooldown = attack
                    self._atk_drop_now = True                      # (AX) this step's rho jump is the ATTACK, not forecast error
        self._atk_onset[_ls] = -1                                  # back IN service -> its attack is over
        self._prev_ls = _ls.copy()
        self._atk_now[:] = False
        self._atk_probe_due = []
        for _k in np.where(self._atk_onset >= 0)[0]:
            _k = int(_k); _age = _now - self._atk_onset[_k]
            if _age > ATK_MAX_DUR:
                self._atk_onset[_k] = -1                           # certainly over -> reconnect normally
                continue
            self._atk_now[_k] = True                               # (v7.1) DOWN in EVERY calculation until it is REALLY back
            if _age >= ATK_MIN_HOLD and (_now - self._atk_probe[_k]) >= ATK_PROBE_EVERY:
                self._atk_probe_due.append(_k)                     # the probe rides on the FINAL action only (see act)
        # (v21) lines the AGENT is holding down -- not the opponent's, not maintenance. Each one is islanding
        # surface: it prices the next shed and rewards the next reconnect.
        _held_down = int(np.sum((~np.asarray(obs.line_status, dtype=bool)) & (~self._atk_now)
                                & (np.asarray(obs.time_next_maintenance, dtype=int) != 0)))
        if self._fc_rho_prev is not None and len(self._fc_rho_prev) == nl:
            if getattr(self, "_atk_drop_now", False):
                # (AX2, user idea) REPAIR the reference instead of skipping: re-forecast the PREVIOUS state
                # with the just-attacked line(s) held out -> the topology jump is factored OUT of the reference,
                # so a TRUE forecast error is measured and applied immediately at the detection step.
                _ref = None
                try:
                    _po = getattr(self, "_prev_obs", None)
                    if _po is not None:
                        _ka = [int(k) for k in np.where(self._atk_onset == _now)[0]]
                        if _ka:
                            _dact = gd.action_space({"set_line_status": [(k, -1) for k in _ka]})
                            _rr = None
                            _pa = (getattr(self, "_last_final_act", None))   # (FIX1 F6) the action committed at t-1, attacked lines held out
                            if _pa is not None:
                                try:
                                    _pa2 = _pa.copy(); _pa2._set_line_status[_ka] = 0   # (FIX1b F6) zeros are safe to write
                                    _pa2._set_topo_vect[self.or_pos[_ka]] = 0; _pa2._set_topo_vect[self.ex_pos[_ka]] = 0
                                    _pa2 = _pa2 + _dact   # (FIX1b F6) grid2op's own addition sets the status flags: attacked lines out
                                    _rr2 = _po.simulate(_pa2, time_step=1)
                                    _i2 = _rr2[3] if len(_rr2) > 3 and isinstance(_rr2[3], dict) else {}
                                    if not ((len(_rr2) > 2 and _rr2[2]) or _i2.get("is_illegal") or _i2.get("is_ambiguous") or _i2.get("exception")): _rr = _rr2
                                except Exception:
                                    _rr = None
                            if _rr is None: _rr = _po.simulate(_dact, time_step=1)
                            if not (len(_rr) > 2 and _rr[2]):
                                _ref = np.asarray(_rr[0].rho, dtype=float)
                except Exception:
                    _ref = None
                if _ref is not None and len(_ref) == nl:
                    _under = np.asarray(obs.rho, dtype=float) - _ref
                    _under = np.where(np.isfinite(_under), _under, 0.0)
                    self._rho_corr = POR_CORR_ALPHA * np.clip(_under, 0.0, POR_CORR_CAP)   # (CORRWIN)
                # else: reference unavailable (islanding sim / no prev obs) -> keep the previous estimate (AX fallback)
            else:
                _refN = self._fc_rho_prev
                _ak = (getattr(self, "_fc_alt_k", None))   # (FIX1 F5) probes rode on the last action and none came back -> the reference without them
                if _ak and getattr(self, "_fc_rho_prev_alt", None) is not None and len(self._fc_rho_prev_alt) == nl and not any(bool(obs.line_status[int(k)]) for k in _ak):
                    _refN = self._fc_rho_prev_alt
                _under = np.asarray(obs.rho, dtype=float) - _refN
                _under = np.where(np.isfinite(_under), _under, 0.0)
                self._rho_corr = POR_CORR_ALPHA * np.clip(_under, 0.0, POR_CORR_CAP)   # (CORRWIN)
        else:
            self._rho_corr = self._rho_corr if (FIX1_ON and USE_POR_CORR and isinstance(getattr(self, "_rho_corr", None), np.ndarray) and len(self._rho_corr) == nl) else np.zeros(nl)   # (FIX1 F7) no reference -> keep the last estimate
        self._fc_rho_prev = None; self._fc_rho_prev_alt = None; self._fc_alt_k = None
        self._prev_obs = obs                                      # (AX2) keep the raw previous observation
        corr = (self._rho_corr)
        _CA_NOW[0] = (np.asarray(corr, dtype=float).copy())   # (CA)
        _wpm = int(getattr(obs, "month", 0))
        _tn1 = TRIP_N1_LIMIT_SP if _wpm in TN_SP_MON else TRIP_N1_LIMIT   # (TNsp) season-based post-trip bar
        self._wp_gate = (bool(np.any(np.asarray(obs.timestep_overflow, dtype=int) > 0))
                         and _wpm in (12, 1, 2, 3))                     # (WPGW) WINTER month AND live counter
        self._gpt_planning_obs = _gpt_maintenance_view(self, obs)
        obs = self._gpt_planning_obs
        self._ovf_now = np.asarray(obs.timestep_overflow, dtype=int)
        self._wp_gate = bool(np.any(self._ovf_now > 0)) and _wpm in (12, 1, 2, 3)
        # ---- (0) RECONNECT-FIRST ----
        RECO = ((None))   # (S1)   # (S2) no restoration is decided before the security check
        def fin(a):
            _gpt_a_require(self,obs,a)
            _pfx = (self._gpt_a_prefix)   # (S2) the Phase C prefix, once chosen (None before)
            out = a if _pfx is None else (_pfx + a)
            if self._atk_now.any():                          # (FIX) keep actively-attacked lines DOWN in the opponent-free forecast/commit
                if out is a: out = a.copy()                  # don't mutate a precomputed candidate action
                aw = np.where(self._atk_now)[0]
                out._set_topo_vect[self.or_pos[aw]] = 0       # strip any bus on the dead line's ends, else obs.simulate
                out._set_topo_vect[self.ex_pos[aw]] = 0       # PHANTOM-RECONNECTS it (no opponent in the forecast) -> optimistic score
                out._set_line_status[aw] = 0                  # and never reconnect an actively-attacked line
            _dnl = np.where(~np.asarray(obs.line_status, dtype=bool))[0]
            if len(_dnl):
                _dnl = _dnl[np.asarray(out._set_line_status)[_dnl] != 1]
                if len(_dnl) and (np.any(np.asarray(out._set_topo_vect)[self.or_pos[_dnl]] != 0) or np.any(np.asarray(out._set_topo_vect)[self.ex_pos[_dnl]] != 0)):
                    if out is a: out = a.copy()
                    out._set_topo_vect[self.or_pos[_dnl]] = 0; out._set_topo_vect[self.ex_pos[_dnl]] = 0
            return self._mnt_strip(obs, out)                 # (v14) the SAME phantom exists for next-step-maintenance lines
        try:
            fc_res = obs.simulate(fin(do_nothing), time_step=1)
            fc = fc_res[0]
            if len(fc_res) > 2 and fc_res[2]: raise ValueError("Forecast predicts game over")
            base_sim = fc.get_simulator(); gm = base_sim.backend._grid; self._nwt_grid = gm   # (NWT) the forecast state of THIS step
            V0 = np.asarray(gm.get_V()); assert V0 is not None and len(V0) > 0
        except Exception:
            # (NOENV) forecast failed: fc = obs (the protective fallback) and the DC split screen uses the observation's own
            # simulator (forecast model at the live state). It used to read self.env.backend._grid = the never-stepped
            # template env (on the scorer the evaluation env's grid.json at its make()-time topology).
            RECO = None; self._gpt_a_prefix=None; fc = obs; base_sim = obs.get_simulator(); gm = base_sim.backend._grid; V0 = np.asarray(gm.get_V()); self._nwt_grid = gm   # (NWT) (NOENV) the observation's own simulator
        # ---- (P2) store this step's forecast for next-step calibration ----
        self._fc_rho_prev = (np.asarray(fc.rho, dtype=float).copy() if (fc is not obs or not FIX1_ON) else None)   # (FIX1 F7) the fallback fc = obs is a measurement, not a forecast
        self._T_mark('s2_sec')
        _S2 = self._s2_begin(obs, fc, fin, base_sim)
        if _S2['dn']['clear']:
            _mntd_secure = self._s2_phase_b(_S2)
            if not _S2.get('mntd_data'): return _mntd_secure
        else: _mntd_secure = None
        # ---- (0b) CHEAP secure gate ----
        _onc = np.where(fc.line_status)[0]
        active_ovf = bool(np.any(obs.timestep_overflow > 0))
        imminent_maint = bool(np.any((obs.time_next_maintenance > 0) & (obs.time_next_maintenance <= MAINT_HORIZON)))
        _fpr = (FASTPATH_RHO)
        _fpmax = float((fc.rho[_onc] + corr[_onc]).max())
        _pre_danger = False
        _cc = []   # (FIX1 F4) the fast path also checks the credible contingencies by exact (true) N-1: top attackable line per area
        for lines_a in self.attack_by_area:
            _ins = [k for k in lines_a if fc.line_status[k]]
            if _ins: _cc.append(int(max(_ins, key=lambda k: _cx(fc.rho)[k])))
        _secB = False
        if _secB:
            credible_cheap = list(_cc)
            self._rg_fc = fc   # (RAMPGUARD)
            if RECO is not None:
                return fin(do_nothing), dict(secure=False, sub=-1, rl=[], cl=[], sl=[], base=float(fc.rho[_onc].max()), n1=-1, pb=float(fc.rho[_onc].max()), pn=-1, ov="RC", status="RECONNECT")
            return do_nothing, dict(secure=True)
        base_bridges = self._bridge_lines(fc)
        Y0 = np.array(gm.get_Ybus().todense()); nB = Y0.shape[0]
        P0 = fc.p_or.astype(float); Q0 = fc.q_or.astype(float); rho0 = fc.rho.astype(float)
        Slim = ((np.where((rho0 > 1e-4) & np.asarray(fc.line_status, dtype=bool), np.sqrt(P0**2 + Q0**2) / np.maximum(rho0, 1e-6), 1e6)))   # (FIX1 F19)
        on = np.where(fc.line_status)[0]
        gp = fc.gen_p.astype(float); lp = fc.load_p.astype(float); lq = fc.load_q.astype(float)
        Wc = [g for g in range(gd.n_gen) if gd.gen_renewable[g] and gp[g] > 1e-3]
        nu = len(Rgen) + len(Wc) + n_sto
        def legal(c):
            if not _gpt_a_compatible(self,obs,c):return False
            s = sub_of(c)
            if s < 0: return True
            if obs.time_before_cooldown_sub[s] > 0: return False
            return all(obs.time_before_cooldown_line[k] == 0 for k in incident[s])
        _wb = {}
        def _prep_inner(c):   # (TIME) wrapped below
            if not _gpt_a_compatible(self,obs,c):return None
            sc = base_sim.predict(self._mnt_strip(obs, self._atk_strip(obs, c)))
            if not getattr(sc, "converged", False): return None
            oc = sc.current_obs
            try: Yp = np.array(sc.backend._grid.get_Ybus().todense())
            except Exception: return None
            if Yp.shape[0] != nB or float(oc.rho.max()) < 0.1 or float(oc.rho.max()) > 5: return None
            llp = _ll(oc); Gr, Br, Bpr = _gbbp(Yp); fV = _fixedV(oc); M, kP, kQ = _redM(Gr, Br, Bpr, fV)
            Mi = None
            if not _wb:
                try: Mi = np.linalg.inv(M)
                except Exception: return None
                _wb.update(M0=M, Mi0=Mi, kP0=kP, kQ0=kQ)
            elif (M.shape == _wb["M0"].shape and np.array_equal(kP, _wb["kP0"]) and np.array_equal(kQ, _wb["kQ0"])):
                dM = M - _wb["M0"]; R = np.where(np.abs(dM).sum(1) > 1e-9)[0]
                if len(R) == 0:
                    Mi = _wb["Mi0"]
                elif len(R) <= M.shape[0] // 3:
                    Mi0 = _wb["Mi0"]; VMi = dM[R, :] @ Mi0
                    inner = np.eye(len(R)) + VMi[:, R]
                    try: Mi = Mi0 - Mi0[:, R] @ np.linalg.solve(inner, VMi)
                    except Exception: Mi = None
            elif np.array_equal(kP, _wb["kP0"]):
                kQs = set(int(x) for x in kQ); kQ0s = set(int(x) for x in _wb["kQ0"])
                Qaug = np.array(sorted(kQ0s | kQs)); nkP = len(kP); N = nkP + len(Qaug)
                pos0 = list(range(nkP)) + [nkP + p for p, q in enumerate(Qaug) if int(q) in kQ0s]
                A0 = np.eye(N);  A0[np.ix_(pos0, pos0)] = _wb["M0"]
                A0i = np.eye(N); A0i[np.ix_(pos0, pos0)] = _wb["Mi0"]
                Aa = np.zeros((N, N))
                Aa[:nkP, :nkP] = (-Bpr)[np.ix_(kP, kP)]; Aa[:nkP, nkP:] = Gr[np.ix_(kP, Qaug)]
                Aa[nkP:, :nkP] = (-Gr)[np.ix_(Qaug, kP)]; Aa[nkP:, nkP:] = (-Br)[np.ix_(Qaug, Qaug)]
                for p, q in enumerate(Qaug):
                    if int(q) not in kQs: r = nkP + p; Aa[r, :] = 0.0; Aa[:, r] = 0.0; Aa[r, r] = 1.0
                dA = Aa - A0; R = np.where(np.abs(dA).sum(1) > 1e-9)[0]
                if 0 < len(R) <= N // 3:
                    VMi = dA[R, :] @ A0i; inner = np.eye(len(R)) + VMi[:, R]
                    try:
                        Ai = A0i - A0i[:, R] @ np.linalg.solve(inner, VMi)
                        pos = list(range(nkP)) + [nkP + p for p, q in enumerate(Qaug) if int(q) in kQs]
                        Mi = Ai[np.ix_(pos, pos)]
                    except Exception: Mi = None
            if Mi is None:
                try: Mi = np.linalg.inv(M)
                except Exception: return None
            n1 = len(kP); H, J, K, F = Mi[:n1, :n1], Mi[:n1, n1:], Mi[n1:, :n1], Mi[n1:, n1:]
            ThP = np.zeros((nB, nB)); ThP[np.ix_(kP, kP)] = H; VP = np.zeros((nB, nB)); VP[np.ix_(kQ, kP)] = K
            ThQ = np.zeros((nB, nB)); ThQ[np.ix_(kP, kQ)] = J; VQ = np.zeros((nB, nB)); VQ[np.ix_(kQ, kQ)] = F
            Gij, Bpij, Bij = flowsens(Yp, llp, Bpr)     # Bpr computed at prep entry -> skip the duplicate _gbbp (exact)
            SF = Gij @ VP + Bpij @ ThP; PQ = Gij @ VQ + Bpij @ ThQ; QP = Bij @ VP - Gij @ ThP; QQ = Bij @ VQ - Gij @ ThQ
            fb, tb = llp[:, 0], llp[:, 1]; pdd = {x: m[:, fb] - m[:, tb] for x, m in [("PP", SF), ("PQ", PQ), ("QP", QP), ("QQ", QQ)]}
            dPP, dPQ, dQP, dQQ = pdd["PP"], pdd["PQ"], pdd["QP"], pdd["QQ"]
            Tpp = np.diagonal(dPP); Tpq = np.diagonal(dPQ); Tqp = np.diagonal(dQP); Tqq = np.diagonal(dQQ)
            h = (1 - Tpp) * (1 - Tqq) - Tpq * Tqp; rad = np.abs(h) < 1e-3
            hs = np.where(rad, 1.0, h); a11 = (1 - Tqq) / hs; a12 = Tpq / hs; a21 = Tqp / hs; a22 = (1 - Tpp) / hs
            L = {"PP": dPP * a11 + dPQ * a21, "PQ": dPP * a12 + dPQ * a22,
                 "QP": dQP * a11 + dQQ * a21, "QQ": dQP * a12 + dQQ * a22}
            if rad.any():
                for x in L: L[x][:, rad] = np.nan
            P0c = oc.p_or.astype(float); Q0c = oc.q_or.astype(float)
            gbus = (gen_sub + (oc.topo_vect[gen_pos] - 1) * ns).astype(int); AGW = np.zeros((nB, nu))
            for j, g in enumerate(Rgen): AGW[gbus[g], j] += 1.0
            for j, g in enumerate(Wc): AGW[gbus[g], len(Rgen) + j] += 1.0
            if n_sto > 0:
                sbus = (self.storage_sub + (oc.topo_vect[self.storage_pos] - 1) * ns).astype(int)
                for j in range(n_sto): AGW[sbus[j], len(Rgen) + len(Wc) + j] += 1.0
            return dict(P0=P0c, Q0=Q0c, SF=SF, L=L, AGW=AGW, rad=rad, sub=sub_of(c), act=c, oc=oc)
        self._T_mark('secure_chk')   # (TIME)
        def prep(c):   # (TIME)
            _tp = time.time(); _T['prep_calls'] = _T.get('prep_calls', 0) + 1
            try: return _prep_inner(c)
            finally: _T['prep_s'] = _T.get('prep_s', 0.0) + (time.time() - _tp)
        # ---- (1) trigger ----
        dn = prep(do_nothing)
        try:    # (rider) stash gen->line MW sensitivities for the act()-level countdown rider
            self._rider_pack = dict(step=int(getattr(obs, "current_step", -1)),
                                    S=dn["SF"] @ dn["AGW"], P0=np.asarray(dn["P0"], dtype=float),
                                    nR=len(Rgen), nW=len(Wc), Rgen=list(Rgen))
        except Exception:
            self._rider_pack = None
        _ordinary = (_mntd_secure if _mntd_secure is not None else self._s2_phase_c(_S2, dn, prep, legal, Y0, P0, Q0, Slim, on, gp, lp))   # (MNTD)
        if _S2.get('mntd_data'):
            if _mntd_secure is not None or str(_ordinary[1].get('status', '')).startswith(('BEST', 'REJECT')):
                return self._s2_mntd(_S2, _ordinary, prep, legal)
            _s2_cnt('mntd_deferred')   # (MNTD) source cleared an insecure step
        return _ordinary

    # ===================== grid2op agent interface =====================


    def act(self, observation, reward, done):
        if not getattr(self, '_p2', False):   # (P1S) unscored pass: spend nothing
            return self.do_nothing
        self._nwt_rate = np.array(observation.thermal_limit, dtype=float)   # (NOENV) limits from the observation, not the env
        _cl_fcfix(self, observation)   # (FCFIX)
        _t_step = time.time()   # (TIME)
        try:
            a = self.decide(observation)[0]
        except _GPTPhaseAConflict:
            PHASEA_JOINT_DIAG['decision_fallback']+=1
            self._T_close(); return getattr(self,'_gpt_a_prefix',None) or self.do_nothing
        except Exception as ex:
            PHASEA_JOINT_DIAG['errors']+=1
            self._decide_err_n = getattr(self, '_decide_err_n', 0) + 1   # (FIX1b F10) own counter
            if self._decide_err_n <= 5:   # (FIX1 F10)
                import traceback as _tbk; print('DECIDE-ERROR step=%s %s' % (getattr(observation, 'current_step', -1), _tbk.format_exc()[-1500:]), flush=True)
            if len(PHASEA_JOINT_DIAG['error_examples'])<10:PHASEA_JOINT_DIAG['error_examples'].append(dict(step=int(observation.current_step),error=repr(ex)))
            self._T_close(); return getattr(self,'_gpt_a_prefix',None) or self.do_nothing
        observation = getattr(self, '_gpt_planning_obs', observation)
        self._T_close(); _T = self.__dict__.setdefault('_T', {})   # (TIME)
        _T['step_total'] = _T.get('step_total', 0.0) + (time.time() - _t_step); _T['steps'] = _T.get('steps', 0) + 1
        if _T['steps'] % 288 == 0: print('STAGETIME', {k: (round(v, 2) if isinstance(v, float) else v) for k, v in sorted(_T.items())}, flush=True)
        if _T['steps'] % 288 == 0: print('S2DIAG', dict(sorted(S2_DIAG.items())), flush=True)   # (S2)
        _gpt_a_before_riders=a.copy()
        # ---- (rider) COUNTDOWN MW RIDER: force real MW into the action while a soft-trip counter runs ----
        try:
            _ovf = np.asarray(observation.timestep_overflow, dtype=int)
            _rp = getattr(self, "_rider_pack", None)
        except Exception:
            pass
        # ---- (v7.1) PROBE RIDER: attach attacked-line reconnect attempts to the FINAL action only.
        # decide() and every forecast treated the line as DOWN (fin strips it everywhere); the attempt
        # is added here so the grid only counts the line once it REALLY reconnects (opponent gone).
        try:
            self._probe_sent = []   # (FIX1 F11)
            for _k in getattr(self, "_atk_probe_due", []):
                _k = int(_k)
                if int(observation.time_before_cooldown_line[_k]) != 0:
                    continue                                    # reconnect would be ILLEGAL now -> retry next step
                if 0 <= int(observation.time_next_maintenance[_k]) <= 1:
                    continue                                    # in maintenance, or it starts next step -> not ours to reconnect
                _ar = int(self.sub_area[self.or_sub[_k]])
                _ch = np.where(np.asarray(a._set_line_status) != 0)[0]
                if any(int(self.sub_area[self.or_sub[int(_l)]]) == _ar for _l in _ch):
                    continue                                    # area's line-change budget already spent -> retry next step
                _cand = a + self.gd.action_space({"set_line_status": [(_k, 1)]})
                if not _gpt_a_budget(self, observation, _cand): continue   # (FIX1 F8) grid2op's own area-budget semantics
                try:                                            # SAFETY SCREEN only - its result feeds NO decision
                    _r = observation.simulate(_cand, time_step=1)
                    if len(_r) > 2 and _r[2]: continue
                    _ri = _r[3] if len(_r) > 3 and isinstance(_r[3], dict) else {}
                    if _ri.get('is_illegal') or _ri.get('is_ambiguous') or _ri.get('exception'): continue   # (FIX1 F8) read the verdict
                    _eb = float(_cx(_r[0].rho).max())   # (CA)
                    if (not np.isfinite(_eb)) or _eb >= max(RECO_CAP, float(observation.rho.max())):
                        continue
                except Exception:
                    continue
                a = _cand
                self._probe_sent.append((_k, int(getattr(observation, "current_step", 0))))
        except Exception:
            pass
        a=_gpt_a_final(self,observation,a,_gpt_a_before_riders)
        for _kp, _tp in getattr(self, "_probe_sent", []):   # (FIX1 F11) only probes still in the final action count as sent
            if int(np.asarray(a._set_line_status)[int(_kp)]) == 1: self._atk_probe[int(_kp)] = _tp
        self._probe_sent = []
        # ---- (P6) TWO-PHASE ask ledger ----------------------------------------------------------------
        # baseEnv.py:2107-2113 treats a generator differently once it is in _already_modified_gen, and that
        # set is monotone within an episode (reset only by _reset_redispatching at :2060).  We mirror it.
        # F6: we may NOT record an ask at emission time.  env.step replaces the whole action with do-nothing
        # at :3713 (ambiguous), :3740 (invalid reconnection) and :3761 (illegal), all BEFORE
        # _get_already_modified_gen runs at :3188 -- so the env would never register an ask we recorded, and
        # from then on U1 would key that generator on td (= 0) and leave its residue frozen for good.
        # Instead: remember what target_dispatch the env MUST show next step, and promote only on a match.
        try:
            _pend = self._econ_pend
            if _pend:
                _tdn = np.asarray(observation.target_dispatch, dtype=float)
                for _gi, _exp in _pend.items():
                    if abs(float(_tdn[_gi]) - float(_exp)) <= RETIRE_CONFIRM_TOL:
                        self._econ_asked[_gi] = True
                    pass
                self._econ_pend = {}
            if getattr(a, "_modif_redispatch", False):
                _rr = np.asarray(a._redispatch, dtype=float)
                _td0 = np.asarray(observation.target_dispatch, dtype=float)
                _ad0 = np.asarray(observation.actual_dispatch, dtype=float)
                _am0 = self._econ_asked
                _pd = {}
                for _gi in np.where(np.abs(_rr) > 1e-7)[0]:
                    _gi = int(_gi)
                    _pd[_gi] = (float(_td0[_gi]) if bool(_am0[_gi]) else float(_ad0[_gi])) + float(_rr[_gi])
                self._econ_pend = _pd
        except Exception:
            pass
        if isinstance(observation, _GPTMaintenanceView):
            a = observation.strip(a)
        return a

    def train(self, env, num_workers, max_training_time):
        return

    def save_state(self, path):
        return

    def load_state(self, path):
        self._p2 = True                    # (P1S) only the scored pass-2 instance gets this call
        return


def make_agent(env, this_directory_path):
    return MyAgent(env)
GPT_DIAGNOSTICS = dict(extra_calls=0, valid=0, unavailable=0,
    reference_replaced=0, nonzero_diff=0, baseline_unavailable=0,
    pass1_skipped=0, copy_failures=0, reason_exception=0,
    reason_done=0, reason_illegal=0, reason_ambiguous=0,
    reason_nonfinite=0, reason_shape=0, reason_horizon=0,
    reason_info=0, reason_result=0)
import copy as _pv_copy   # (PRIVOBS)
_ACTION_REFERENCE_ORIGINAL_ACT = MyAgent.act


def _action_reference_reject(reason):
    GPT_DIAGNOSTICS["unavailable"] += 1
    GPT_DIAGNOSTICS["reason_" + reason] += 1


def _action_reference_forecast(observation, action):
    # Isolate simulation-side action mutation and vector caches from the exact
    # original action returned to Runner. Never call live action.to_vect().
    try:
        trial_action = action.copy()
    except Exception:
        GPT_DIAGNOSTICS["copy_failures"] += 1
        _action_reference_reject("exception")
        return None
    try:
        expected_step = int(observation.current_step) + 1
        expected_shape = np.asarray(observation.rho).shape
        GPT_DIAGNOSTICS["extra_calls"] += 1
        result = observation.simulate(trial_action, time_step=1)
    except Exception:
        _action_reference_reject("exception")
        return None
    try:
        if not isinstance(result, (tuple, list)) or len(result) != 4:
            _action_reference_reject("result")
            return None
        forecast, _reward, is_done, info = result
        if not isinstance(info, dict):
            _action_reference_reject("info")
            return None
        if bool(info.get("is_illegal", False)):
            _action_reference_reject("illegal")
            return None
        if bool(info.get("is_ambiguous", False)):
            _action_reference_reject("ambiguous")
            return None
        if bool(is_done):
            _action_reference_reject("done")
            return None
        if info.get("exception"):
            _action_reference_reject("exception")
            return None
        if int(forecast.current_step) != expected_step:
            _action_reference_reject("horizon")
            return None
        rho = np.asarray(forecast.rho, dtype=float)
        if rho.ndim != 1 or rho.shape != expected_shape or rho.size == 0:
            _action_reference_reject("shape")
            return None
        if not np.isfinite(rho).all() or (rho < 0.0).any():
            _action_reference_reject("nonfinite")
            return None
        GPT_DIAGNOSTICS["valid"] += 1
        return rho.copy()
    except Exception:
        _action_reference_reject("exception")
        return None


def _act_with_action_reference(self, observation, reward, done):
    if getattr(self, '_p2', False):   # (PRIVOBS) (S2CLNSM6CNP) the decision and the final-action forecast run on a PRIVATE copy;
        observation = _pv_copy.deepcopy(observation)   # the env's own observation object is never written to
    # The original call finishes every final rider and ledger update first.
    # Deliberately outside try: do not mask exceptions from the original act.
    action = _ACTION_REFERENCE_ORIGINAL_ACT(self, observation, reward, done)
    if not getattr(self, '_p2', False):
        GPT_DIAGNOSTICS["pass1_skipped"] += 1
        return action
    self._last_final_act = action
    rho = _action_reference_forecast(observation, action)
    if rho is None:
        return action
    try:
        _ks = [int(k) for k in np.where((np.asarray(action._set_line_status) == 1) & np.asarray(self._atk_now, dtype=bool))[0]]
        if _ks:
            _alt = action.copy(); _alt._set_line_status[_ks] = 0
            _alt._set_topo_vect[self.or_pos[_ks]] = 0; _alt._set_topo_vect[self.ex_pos[_ks]] = 0
            _ra = _action_reference_forecast(observation, _alt)
            if _ra is not None: self._fc_rho_prev_alt = _ra; self._fc_alt_k = _ks
    except Exception:
        pass
    baseline = getattr(self, "_fc_rho_prev", None)
    try:
        baseline = np.asarray(baseline, dtype=float)
        comparable = baseline.shape == rho.shape and np.isfinite(baseline).all()
    except Exception:
        comparable = False
    if comparable:
        if np.any(np.abs(rho - baseline) > 1e-9):
            GPT_DIAGNOSTICS["nonzero_diff"] += 1
    else:
        GPT_DIAGNOSTICS["baseline_unavailable"] += 1
    self._fc_rho_prev = rho
    GPT_DIAGNOSTICS["reference_replaced"] += 1
    return action


def _act_release(self, observation, reward, done):   # (ZE3) (S2CLNSM6CZ3) D-1: drop the per-step objects after every act
    try:
        return _act_with_action_reference(self, observation, reward, done)
    finally:
        self._gpt_planning_obs = None; self._leth_dn_st = None; self._rg_fc = None


MyAgent.act = _act_release




WITHDRAWAL_DIAGNOSTICS = dict(calls=0,triggered=0,accepted=0,rejected=0,errors=0,examples=[],error_examples=[])




WITHDRAWAL_DIAGNOSTICS.update(directional_calls=0,up_target_increased=0,down_target_increased=0,horizon_unavailable=0,horizon_examples=[],directional_examples=[])

# Explicit next-step maintenance planning. The real observation is never edited.
MAINTENANCE_VIEW_DIAG = dict(calls=0,active_steps=0,lines=0,powerflow_failed=0,
                            simulations=0,errors=0,examples=[],error_examples=[])

def _gpt_mnt_fingerprint(obs):
    import hashlib
    h=hashlib.sha256()
    for name in ['line_status','topo_vect','rho','timestep_overflow','gen_p','load_p',
                 'actual_dispatch','target_dispatch','storage_power','storage_charge',
                 'curtailment_limit','time_next_maintenance']:
        h.update(np.asarray(getattr(obs,name)).tobytes())
    h.update(str(int(obs.current_step)).encode())
    return h.hexdigest()

class _GPTMaintenanceView:
    def __init__(self,owner,base,raw,lines):
        self._owner=owner;self._base=base;self._lines=np.asarray(lines,int)
    def __getattr__(self,name):return getattr(self._base,name)
    def strip(self,action):
        out=action.copy();ks=self._lines
        out._set_line_status[ks]=0
        out._set_topo_vect[self._owner.or_pos[ks]]=0
        out._set_topo_vect[self._owner.ex_pos[ks]]=0
        if hasattr(out,'_switch_line_status'):out._switch_line_status[ks]=False
        if hasattr(out,'_change_bus_vect'):
            out._change_bus_vect[self._owner.or_pos[ks]]=False
            out._change_bus_vect[self._owner.ex_pos[ks]]=False
        # A scheduled outage is an environment event, not a manual switch.
        if hasattr(out,'_vectorized'):out._vectorized=None
        return out
    def simulate(self,action,time_step=1):
        d=MAINTENANCE_VIEW_DIAG;d['simulations']+=1
        result=self._base.simulate(self.strip(action),time_step=time_step)
        if not result[2] and np.any(np.asarray(result[0].line_status,bool)[self._lines]):
            d['errors']+=1
            if len(d['error_examples'])<10:d['error_examples'].append('A protected maintenance line reconnected in a valid forecast')
            raise RuntimeError('Maintenance planning invariant failed')
        return result

def _gpt_maintenance_view(self,obs):
    d=MAINTENANCE_VIEW_DIAG;d['calls']+=1
    ks=np.where((np.asarray(obs.time_next_maintenance,int)==1)&np.asarray(obs.line_status,bool))[0]
    if not len(ks):return obs
    before=_gpt_mnt_fingerprint(obs)
    try:
        view=obs.copy()
        view.line_status[ks]=False
        view.topo_vect[self.or_pos[ks]]=-1;view.topo_vect[self.ex_pos[ks]]=-1
        view.timestep_overflow[ks]=0
        line_fields=['rho','p_or','q_or','v_or','a_or','p_ex','q_ex','v_ex','a_ex']
        for name in line_fields:
            if hasattr(view,name):getattr(view,name)[ks]=0.
        sim=view.get_simulator()
        if getattr(sim,'converged',False):
            # This power flow is at current observed injections, with only the
            # known next-step outage topology changed. No time is advanced.
            sim._update_obs()
            for name in line_fields:
                if hasattr(view,name):getattr(view,name)[:]=getattr(sim.current_obs,name)
        else:
            # Retain the outage topology even when its no-action PF diverges.
            # The later search can still evaluate a combined corrective action.
            d['powerflow_failed']+=1
        for name in ['gen_p','load_p','actual_dispatch','target_dispatch','storage_power','storage_charge','curtailment_limit','time_next_maintenance']:
            assert np.array_equal(getattr(view,name),getattr(obs,name),equal_nan=True),name
        assert _gpt_mnt_fingerprint(obs)==before,'Real observation mutated'
        assert int(view.current_step)==int(obs.current_step)
        d['active_steps']+=1;d['lines']+=len(ks)
        if len(d['examples'])<24:d['examples'].append(dict(step=int(obs.current_step),lines=ks.tolist(),powerflow_converged=bool(getattr(sim,'converged',False)),real_observation_unchanged=True))
        return _GPTMaintenanceView(self,view,obs,ks)
    except Exception as ex:
        d['errors']+=1
        if len(d['error_examples'])<10:d['error_examples'].append(repr(ex))
        raise


def _gpt_restore_options(self,obs,reco=None,include_noop=False):
    """All area-legal subsets: <=1 line and <=1 remesh per area. No top-k cap.
    Real Grid2Op legality/ambiguity is also checked by each exact forecast.
    Existing Phase-A reconnects consume their area's line budget when present.
    """
    areas=sorted(set(int(x) for x in self.sub_area if int(x)>=0))
    lines={a:[] for a in areas};subs={a:[] for a in areas};busy=set();done=set()
    if reco is not None:
        done=set(int(k) for k in np.where(np.asarray(reco._set_line_status)!=0)[0])
        busy={int(self.sub_area[self.or_sub[k]]) for k in done}
    for k in np.where(~np.asarray(obs.line_status,bool))[0]:
        k=int(k);area=int(self.sub_area[self.or_sub[k]])
        if area not in lines or area in busy or k in done:continue
        if self._atk_now[k] or int(obs.time_before_cooldown_line[k])!=0:continue
        if 0<=int(obs.time_next_maintenance[k])<=1:continue
        lines[area].append((k,(self._s2_reco(k))))   # (S2 v2) ends on bus 1 (S2_RECO_BUS1)
    for s in range(self.ns):
        a=int(self.sub_area[s])
        if a not in subs or int(obs.time_before_cooldown_sub[s])!=0:continue
        if not np.any(np.asarray(obs.topo_vect)[self.pos2sub==s]==2):continue
        action=self._remesh_action(obs,s)
        if action is not None:subs[a].append((s,action))
    choices=[list(product([None]+lines[a],[None]+subs[a])) for a in areas]
    for selection in product(*choices):
        action=self.do_nothing.copy();ls=[];ss=[]
        for line,sub in selection:
            if line is not None:ls.append(line[0]);action=action+line[1]
            if sub is not None:ss.append(sub[0]);action=action+sub[1]
        if not(ls or ss) and not include_noop:continue
        if action.is_ambiguous()[0]:continue
        yield action,ls,ss



from itertools import product
PHASEA_JOINT_DIAG = dict(calls=0,enumerated=0,valid=0,accepted=0,reconnected=0,unsplit=0,
    max_combinations=0,conflict_rejected=0,rider_reverted=0,decision_fallback=0,
    errors=0,error_examples=[],examples=[])

class _GPTPhaseAConflict(ValueError):
    pass

def _gpt_a_budget(self,obs,action):
    """Use actual Grid2Op impact semantics, including reconnection endpoint exceptions."""
    lines,subs=action.get_topological_impact(np.asarray(obs.line_status,bool),_read_from_cache=False)
    par=self.gd.parameters
    for area in set(int(x) for x in self.sub_area):
        if area<0:continue
        if np.count_nonzero(lines & (self.sub_area[self.or_sub]==area))>par.MAX_LINE_STATUS_CHANGED:return False
        if np.count_nonzero(subs & (self.sub_area==area))>par.MAX_SUB_CHANGED:return False
    if np.any(lines & (np.asarray(obs.time_before_cooldown_line)>0)):return False
    if np.any(subs & (np.asarray(obs.time_before_cooldown_sub)>0)):return False
    return True

def _gpt_a_compatible(self,obs,action,require_prefix=False):
    prefix=getattr(self,'_gpt_a_prefix',None)
    if prefix is None:return True
    pt=np.asarray(prefix._set_topo_vect);ps=np.asarray(prefix._set_line_status)
    at=np.asarray(action._set_topo_vect);als=np.asarray(action._set_line_status)
    tc=np.asarray(action._change_bus_vect,bool);lc=np.asarray(action._switch_line_status,bool)
    if np.any((pt!=0)&(((at!=0)&(at!=pt))|tc)):return False
    if np.any((ps!=0)&(((als!=0)&(als!=ps))|lc)):return False
    if require_prefix and (np.any((pt!=0)&(at!=pt)) or np.any((ps!=0)&(als!=ps))):return False
    _,prefix_subs=prefix.get_topological_impact(np.asarray(obs.line_status,bool),_read_from_cache=False)
    locked_areas=set(int(x) for x in self.sub_area[prefix_subs])
    positions=np.isin(self.sub_area[self.pos2sub],list(locked_areas))
    if np.any(positions & ((at!=0)|tc) & ((pt==0)|(at!=pt)|tc)):return False
    # A later command anywhere else in a used substation area is forbidden;
    # get_topological_impact handles line reconnect endpoint commands separately.
    full=prefix+action
    if full.is_ambiguous()[0]:return False
    return _gpt_a_budget(self,obs,full)

def _gpt_a_require(self,obs,action):
    if not _gpt_a_compatible(self,obs,action):
        PHASEA_JOINT_DIAG['conflict_rejected']+=1
        raise _GPTPhaseAConflict('Conflicts with committed Phase A topology or area allowance')

def _gpt_a_final(self,obs,action,before_riders):
    if getattr(self,'_gpt_a_prefix',None) is None:return action
    if _gpt_a_compatible(self,obs,action,True):return action
    PHASEA_JOINT_DIAG['rider_reverted']+=1
    if _gpt_a_compatible(self,obs,before_riders,True):return before_riders.copy()
    # A confirmed Phase-A action is the final defensive fallback, never bare noop.
    PHASEA_JOINT_DIAG['decision_fallback']+=1
    return self._gpt_a_prefix.copy()

